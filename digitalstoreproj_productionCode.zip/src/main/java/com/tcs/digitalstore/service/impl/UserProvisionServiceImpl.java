package com.tcs.digitalstore.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.tcs.digitalstore.domain.GeMatixUserDetails;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.DocumentRepository;
import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.service.UserProvisionService;
import com.tcs.digitalstore.utility.mailer.NotificationService;
import com.tcs.digitalstore.utility.mailer.NotificationType;
import com.tcs.digitalstore.utility.mailer.PayLoad;


@Service
public class UserProvisionServiceImpl implements UserProvisionService {
	
	
	
	private static final String DEFAULT_ROLE = "Guest";
	private static final String PENDING_FOR_APPROVAL_STATUS = "pending";
	private static final String APPROVED_STATUS="approved";
	
	@Autowired PasswordEncoder passwordEncoder;
	
	@Autowired private UserRepository userDetailRepository;
	
	@Autowired private DocumentRepository documentRepository;
	
	@Autowired private NotificationService notificationService;
	
	public String register(GeMatixUserDetails geMatixUserDetails) {
		
		// Check if the employee is already registered.
		List<User> usersById = userDetailRepository.findByEmployeeId(geMatixUserDetails.getUserId());
		
		if(usersById != null && usersById.size() != 0) {
			throw new InternalException("Employee id: " + geMatixUserDetails.getUserId() + " provided is already registered.");
		}
		
		if(geMatixUserDetails.getUserEmailId() != null && ! geMatixUserDetails.getUserEmailId().isEmpty()) {
			// Check if the email id is already registered.
			List<User> usersByemailId = userDetailRepository.findByMailId(geMatixUserDetails.getUserEmailId().trim().toLowerCase());
			if(usersByemailId != null && usersByemailId.size() != 0) {
				throw new InternalException("Mail id: " + geMatixUserDetails.getUserEmailId() + " provided is already registered.");
			}
		}
		
		// Checking for valid email id
		if(!(geMatixUserDetails.getUserEmailId().toLowerCase()).contains("@tcs.com") && !(geMatixUserDetails.getUserEmailId().toLowerCase()).contains("@tcsin.com")) {
			throw new InternalException("Provided mail id: " + geMatixUserDetails.getUserEmailId() + " is not valid tcs mail id.");
		}
		
		if(! passwordEncoder.matches(geMatixUserDetails.toString(), geMatixUserDetails.getDigest())) {
			throw new InternalException("Data Tempered");
		}
		User user = new User();
		user.setEmployeeId(geMatixUserDetails.getUserId());
		user.setName(geMatixUserDetails.getUserName());
		user.setRole(DEFAULT_ROLE);
		user.setBusinessUnit(geMatixUserDetails.getUserBusiness());
		user.setGeMatixRole(geMatixUserDetails.getPortalRole());
		user.setMailId(geMatixUserDetails.getUserEmailId());
		user.setRegistrationDate(new Date());
		user.setApprovstatus(PENDING_FOR_APPROVAL_STATUS);
		userDetailRepository.save(user);
		
		Map<String,Object> values = new HashMap<>();
		values.put("userName", geMatixUserDetails.getUserName());
		notificationService.send(new PayLoad(geMatixUserDetails.getUserEmailId(),NotificationType.USER_REGISTRATION,values));
		
		return "0";
	}
	
	public String approve(final User userDet) {
		
		// User must be already registered. 
		List<User> users = userDetailRepository.findByEmployeeId(userDet.getEmployeeId());
		if(users == null || users.isEmpty())	{
			throw new InternalException("User record " + "{ Employee Id: "+ userDet.getEmployeeId() + " }" + "to approve not found.");
		}
		User userDetDB = users.get(0);
		
		// Check the approval status of the record. If it is already approved/ rejected then do not proceed. 
		if(! userDetDB.getApprovstatus().equalsIgnoreCase(PENDING_FOR_APPROVAL_STATUS)) {
			throw new InternalException("User record " + "{ Employee Id: "+userDetDB.getEmployeeId() + " }" + " is already apporved/ rejected.");
		}
	
		// Retrieve approver record based on the approver employee id and setup approver details.  
		List<User> approverUsers = userDetailRepository.findByEmployeeId(userDet.getApproverEmployeeId());
		if(approverUsers == null || approverUsers.isEmpty())	{
			throw new InternalException("Approver record " + "{ Employee Id: " + userDetDB.getApproverEmployeeId() + " }" + " not found.");
		}
		User approverDb = approverUsers.get(0);
		userDetDB.setApprovstatus(userDet.getApprovstatus());
		userDetDB.setRole(userDet.getRole());
		userDetDB.setApproverId(approverDb.getId());
		userDetDB.setApproverEmployeeName(approverDb.getName());
		userDetDB.setApproverEmployeeId(approverDb.getEmployeeId());
		userDetDB.setApprovalDate(new Date());
		userDetailRepository.save(userDetDB);
		
		if(userDetDB.getApprovstatus().equalsIgnoreCase(APPROVED_STATUS)) {
			Map<String,Object> templateData = new HashMap<>();
			templateData.put("userName", userDetDB.getName());
			templateData.put("userId", userDetDB.getEmployeeId());
			notificationService.send(new PayLoad(userDetDB.getMailId(),NotificationType.USER_REGISTRATION_APPROVAL,templateData));
		}
		return "0";
	}
	
	@Override
	public String uploadProfilePic(String userId,MultipartFile profilePic)
	{	
		try {
			User userdb = userDetailRepository.findById(userId);
			if(userdb == null) {
				throw new InternalException("User record not found.");
			}
			String fileName =  userdb.getEmployeeId() + "_" + System.currentTimeMillis() + "_" + profilePic.getOriginalFilename();
			
			DBObject metaData = new BasicDBObject();
		    metaData.put("name",fileName);
		    metaData.put("contentType", profilePic.getContentType());
		    
		    String profilePicFileId = documentRepository.store(profilePic.getInputStream(), fileName, profilePic.getContentType(), metaData);
		    userDetailRepository.updateProfilePicId(userdb.getId(),profilePicFileId);
		    return profilePicFileId;
		}
		catch(Exception ex) {
			throw new InternalException("Unexpected error in uploading profile pic.",ex);
		}
	}
}
