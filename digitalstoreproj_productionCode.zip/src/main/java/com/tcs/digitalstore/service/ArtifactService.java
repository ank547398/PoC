package com.tcs.digitalstore.service;

import java.util.List;

import com.mongodb.gridfs.GridFSDBFile;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.DocumentUploaded;
import com.tcs.digitalstore.domain.BusinessAppCountDto;
import com.tcs.digitalstore.domain.IndividualContributor;
import com.tcs.digitalstore.domain.UserFeedConsolidated;
import com.tcs.digitalstore.domain.WorkflowDetails;

public interface ArtifactService {
	
	/**
	 * Contract for adding artifact to digital store.
	 * @param artifact to add
	 * @return 
	 */
	public String add(Artifact artifact,List<DocumentUploaded> documentsUploaded);
	
	public String update(Artifact artifact,List<DocumentUploaded> documentsUploaded);
	
	/**
	 * Contract for approving or rejecting the artifact. 
	 * @param workflowDetails
	 * @return
	 */
	public String approve(WorkflowDetails workflowDetails);
	
	/**
	 * Contract for retrieving file by name. 
	 * @param fileName name of the file to be retrieved.
	 * @return file retrieved. 
	 */
	public GridFSDBFile retrieveByName(String fileName);
	
	/**
	 * Contract for retrieving file by id.
	 * @param fileId of the file to be retrieved. 
	 * @return file of type GridFSDBFile
	 */
	public GridFSDBFile retrieveById(String fileId);
	
	public Artifact getArtifactById(String artifactId);
	
	
	public UserFeedConsolidated getArtifactDtls(String userId,String artifactId);
	
	public List<IndividualContributor> getTopContributors();
	
	public List<BusinessAppCountDto> getTopBusiness();
	
	public List<Artifact> getLatestApps();
	
	public List<Artifact> findByApprovalStatus(String approvalStatus);
}
