package com.tcs.digitalstore.service;

import java.util.List;

import com.tcs.digitalstore.domain.Admin;
import com.tcs.digitalstore.domain.Artifact;

public interface AdminService {
	
	
	public List<Admin> searchAllUsers();
	public List<Artifact> searchAllArtifacts();
	
	public String updateUsers(Admin objAdmin);
	
	public String deleteUsers(String userId);
	public String deleteArtifact(String artifactId);

}
