package com.tcs.digitalstore.service;

import com.tcs.digitalstore.domain.GeMatixUserDetails;

public interface GeMatixAuthService {
	public GeMatixUserDetails authenticate(String userName,String userPassword);
}
