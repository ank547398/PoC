package com.tcs.digitalstore.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.ArtifactRepository;
import com.tcs.digitalstore.repository.AvgRating;
import com.tcs.digitalstore.repository.UserFeedRepository;
import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.service.UserFeedService;

@Component
public class UserFeedServiceImpl implements UserFeedService {
	@Autowired private UserRepository userRepository;
	
	@Autowired private ArtifactRepository artifactRepository;
	
	@Autowired private UserFeedRepository userFeedRepository;
	
	public String unlike(String userId,String artifactId) {
		User userDb = userRepository.findOne(userId);
		if(userDb == null) 		{ return "0"; }
		
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		if(artifactDb == null) 	{ return "0"; }
		
		UserFeed userFeedDb = userFeedRepository.findLikedByUserIdArtifactId(userId, artifactId);
		if(userFeedDb == null)  { return "" + artifactDb.getLikes(); }
		
		userFeedRepository.delete(userFeedDb.getId());
		artifactRepository.updateLikesCount(artifactId,(artifactDb.getLikes() - 1));
		
		return "" + (artifactDb.getLikes() - 1);
	}
	
	public String like(String userId,String artifactId) {
		User userDb = userRepository.findOne(userId);
		if(userDb == null) 		{ return "0"; }
		
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		if(artifactDb == null) 	{ return "0"; }

		// Retrieve details for userFeed corresponding to userId and artifactId
		UserFeed userFeedDb = userFeedRepository.findLikedByUserIdArtifactId(userId, artifactId);
		if(userFeedDb != null)  { return ""+ artifactDb.getLikes(); }
		
		userFeedRepository.save(UserFeed.buildLiked(userId,userDb.getEmployeeId(), userDb.getName(),artifactId,artifactDb.getName()));
		artifactRepository.updateLikesCount(artifactId,(artifactDb.getLikes() + 1));
		return ""+ (artifactDb.getLikes() + 1);
	}
	
	public AvgRating rating(String userId,String artifactId,float rating) {
		if(rating < 0 || rating > 5.0) {
			throw new InternalException("Rating must be more than 0 and less than 5");
		}
		// Retrieve user details corresponding to given user id. 
		User userDb = userRepository.findOne(userId);
		if(userDb == null)  	{ return null; }
		
		// Retrieve artifact details corresponding to given artifact id. 
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		if(artifactDb == null) 	{ return null; }

		// Retrieve details for userFeed corresponding to userId and artifactId.
		UserFeed userFeedDb = userFeedRepository.findRatingByUserIdArtifactId(userId, artifactId);
		if( userFeedDb != null) { 
			userFeedRepository.delete(userFeedDb.getId());
		}  
		// Register user feed. 
		userFeedRepository.save(UserFeed.buildRated(userId,userDb.getEmployeeId(), userDb.getName(),
										artifactId,artifactDb.getName(),rating));
		AvgRating avgRating = userFeedRepository.getAverageRating(artifactId);
		avgRating.setArtifactId(artifactId);
		artifactRepository.updateRating(artifactId,avgRating.getAvgRating() ,avgRating.getUserCount());
		return avgRating;
	}
	
	public String view(String userId,String artifactId) {
		// Retrieve user details corresponding to given user id. 
		User userDb = userRepository.findOne(userId);
		if(userDb == null) { return "0"; }
		
		// Retrieve artifact details corresponding to given artifact id. 
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		if(artifactDb == null) { return "0"; }
		
		UserFeed userFeedDb = userFeedRepository.findViewedByUserIdArtifactId(userId, artifactId);
//		if(userFeedDb != null) { return "2"; } //Commented to increase the views count on each view
		
		userFeedDb = UserFeed.buildViewed(userId,userDb.getEmployeeId(),userDb.getName(),artifactId,artifactDb.getName());
		userFeedRepository.save(userFeedDb);
		artifactRepository.updateviewsCount(artifactId,(artifactDb.getViews() + 1));
		Artifact artifact = artifactRepository.findById(artifactId).get(0);
		return ""+artifact.getViews();
	}
	
	public String download(String userId,String artifactId) {
		// Retrieve user details corresponding to given user id. 
		User userDb = userRepository.findOne(userId);
		if(userDb == null) { return "0"; }
		
		// Retrieve artifact details corresponding to given artifact id. 
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		if(artifactDb == null) { return "0"; }
		
		UserFeed userFeedDb = userFeedRepository.findDownloadedByUserIdArtifactId(userId, artifactId);

//		if(userFeedDb != null) { return "2"; }      //Commented to increase the downloads count on each download
		userFeedDb = UserFeed.buildDownloaded(userId,userDb.getEmployeeId(), userDb.getName(),artifactId,artifactDb.getName());
		userFeedRepository.save(userFeedDb);
		artifactRepository.updatedownloadsCount(artifactId,(artifactDb.getDownloads() + 1));
		Artifact artifact = artifactRepository.findById(artifactId).get(0);
		return ""+artifact.getDownloads();
	}
	
	
}
