package com.tcs.digitalstore.service;

import com.tcs.digitalstore.repository.AvgRating;



public interface UserFeedService {
	String like(String userId,String artifactId);
	String unlike(String userId,String artifactId);
	String view(String userId,String artifactId);
	String download(String userId,String artifactId);
	AvgRating rating(String userId,String artifactId,float rating);
}
