package com.tcs.digitalstore.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.ArtifactDocument;
import com.tcs.digitalstore.domain.BusinessAppCountDto;
import com.tcs.digitalstore.domain.DocumentUploaded;
import com.tcs.digitalstore.domain.IndividualContributor;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.domain.UserFeedConsolidated;
import com.tcs.digitalstore.domain.WorkflowDetails;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.ArtifactRepository;
import com.tcs.digitalstore.repository.DocumentRepository;
import com.tcs.digitalstore.repository.UserFeedRepository;
import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.service.ArtifactService;
import com.tcs.digitalstore.utility.mailer.NotificationService;
import com.tcs.digitalstore.utility.mailer.NotificationType;
import com.tcs.digitalstore.utility.mailer.PayLoad;


@Service
public class ArtifactServiceImpl implements ArtifactService {
	
	@Autowired private UserRepository userRepository;
	@Autowired private ArtifactRepository artifactRepository;
	@Autowired private DocumentRepository documentRepository;
	@Autowired private UserFeedRepository userFeedRepository;
	@Autowired private NotificationService notificationService;
	@Value("${output.file.path}") private String outputFilePath;
	
	
	private DBObject buildDbObject(DocumentUploaded documentUploaded) {
		DBObject metaData = new BasicDBObject();
        metaData.put("name", documentUploaded.getDocument().getOriginalFilename());
        metaData.put("displayName",documentUploaded.getDisplayName());
        metaData.put("uploaderUserName", documentUploaded.getUploaderUserName());
        metaData.put("documentType", documentUploaded.getDocumentType());
        metaData.put("contentType",documentUploaded.getContentType());
        return metaData;
	}
	
	private String getFileExtension(String fileName) {
		int i = fileName.lastIndexOf('.');
		if (i > 0) {
		    return fileName.substring(i+1);
		}
		return "";
	}
	
	@Override
	public String add(Artifact artifact,List<DocumentUploaded> documentsUploaded) {
		Artifact artifactDB;
		// Retrieve the details of the user who is uploading the artifact 
		List<User> userDbs = userRepository.findByEmployeeId(artifact.getUploaderEmployeeId());
		if(userDbs == null || userDbs.isEmpty()) {
			throw new InternalException("Uploader user details not found. {Employee Id: " + artifact.getUploaderEmployeeId() + "}");
		}
		User userDb = userDbs.get(0);

		artifact.setUploaderId(userDb.getId());
		artifact.setUploaderUserName(userDb.getName());
		String fileId;
		List<ArtifactDocument> artifactDocuments = new ArrayList<>();
		try {
			for(DocumentUploaded documentUploaded : documentsUploaded) {
	    		DBObject metaData = buildDbObject(documentUploaded);
	    		fileId = documentRepository.store(documentUploaded.getDocument().getInputStream(), documentUploaded.getFileName(), documentUploaded.getContentType(), metaData);
	    		documentUploaded.setFileId(fileId);
	    		
	    		if(documentUploaded.getDocumentType().equalsIgnoreCase("logo")) {
	            	artifact.setLogoURL(fileId);
	            } else if(documentUploaded.getDocumentType().equalsIgnoreCase("flyer")) {
	            	artifact.setFlyerId(fileId);
	            }
	    		
	    		
	    		String fileExtension = getFileExtension(documentUploaded.getFileName());
	    		documentUploaded.setFileExtension(fileExtension);
	    		
	    		if(fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("ppt")
	    				|| fileExtension.equalsIgnoreCase("docx")||  fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("pptx")
						|| fileExtension.equalsIgnoreCase("odt") || fileExtension.equalsIgnoreCase("ods") || fileExtension.equalsIgnoreCase("odp") 
						|| fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif") || fileExtension.equalsIgnoreCase("jpg") 
						|| fileExtension.equalsIgnoreCase("jpeg") ||fileExtension.equalsIgnoreCase("bmp")) {
	    			documentUploaded.setPdfFileId(fileId);
	    			documentUploaded.setPdf(false);
				} else if(fileExtension.equalsIgnoreCase("pdf")){
					documentUploaded.setPdf(true);
				} else {
					throw new InternalException("Not a valid file type to support. {pdf|doc|xls|ppt|docx|xlsx|pptx|odt|ods|odp|png|gif|jpg|jpeg|bmp}");
				}
	    		artifactDocuments.add(documentUploaded.getArtifactDocument());
	    	}
			artifact.setArtifactDocuments(artifactDocuments);
			artifact.setApprovalStatus("pending");
			artifactDB = artifactRepository.save(artifact);
			if(artifactDB == null) {
				throw new InternalException("Failed to upload artifact {name: " + artifact.getName() + "}");
			}
		} catch(Exception ex) {
			throw new InternalException("Failed to upload the artifact.");
		}
		
		// Send notification to the user.
		Map<String,Object> templateData = new HashMap<>();
		templateData.put("userName", userDb.getName());
		templateData.put("appName", artifactDB.getName());
		notificationService.send(new PayLoad(userDb.getMailId(),NotificationType.APP_UPLOADED, templateData));
		return "1";
	}
	
	public String update(Artifact artifact,List<DocumentUploaded> documentsUploaded) {
		Artifact artifactDB;
		
		// Retrieve the details of the user who is uploading the artifact 
		List<User> userDbs = userRepository.findByEmployeeId(artifact.getUploaderEmployeeId());
		if(userDbs == null || userDbs.isEmpty()) {
			throw new InternalException("Uploader user details not found. {Employee Id: " + artifact.getUploaderEmployeeId() + "}");
		}
		User userDb = userDbs.get(0);

		Artifact objArtifactDB = artifactRepository.findOne(artifact.getOldArtifactId());
		if(objArtifactDB.getModifyCount() == 1) {
			return "0";
		}
		objArtifactDB.setModifyCount(1);

		List<ArtifactDocument> lstArtifactDocs = new ArrayList<ArtifactDocument>();
		List<ArtifactDocument> lstArtifactDocs1 = new ArrayList<ArtifactDocument>();

		lstArtifactDocs = objArtifactDB.getArtifactDocuments();
		for(ArtifactDocument artifactDoc : lstArtifactDocs) {
			if(artifactDoc.getDocumentType().equals("logo")) {
				artifact.setLogoURL(artifactDoc.getFileId());
			}
			for(int i=0 ; i < artifact.getDeletedFileId().size() ; i++)
			{
				if(artifactDoc.getFileId().equals(artifact.getDeletedFileId().get(i)))
				{
					lstArtifactDocs1.add(artifactDoc);
				}
			}
		}

		lstArtifactDocs.removeAll(lstArtifactDocs1);
		// System.out.println("lstArtifactDocs :"+lstArtifactDocs);


		artifact.setDownloads(objArtifactDB.getDownloads());
		artifact.setRating(objArtifactDB.getRating());
		artifact.setRatingCount(objArtifactDB.getRatingCount());
		artifact.setViews(objArtifactDB.getViews());
		artifact.setLikes(objArtifactDB.getLikes());
		artifact.setPopularityPercent(objArtifactDB.getPopularityPercent());

		artifact.setUploaderId(userDb.getId());
		artifact.setUploaderUserName(userDb.getName());
		String fileId;
		List<ArtifactDocument> artifactDocuments = new ArrayList<>();
		artifactDocuments.addAll(lstArtifactDocs);
		try {
			for(DocumentUploaded documentUploaded : documentsUploaded) {
	    		DBObject metaData = buildDbObject(documentUploaded);
	    		fileId = documentRepository.store(documentUploaded.getDocument().getInputStream(), documentUploaded.getFileName(), documentUploaded.getContentType(), metaData);
	    		documentUploaded.setFileId(fileId);

	    		if(documentUploaded.getDocumentType().equalsIgnoreCase("logo")) {
	            	artifact.setLogoURL(fileId);
	            } else if(documentUploaded.getDocumentType().equalsIgnoreCase("flyer")) {
	            	artifact.setFlyerId(fileId);
	            }


	    		String fileExtension = getFileExtension(documentUploaded.getFileName());
	    		documentUploaded.setFileExtension(fileExtension);

	    		if(fileExtension.equalsIgnoreCase("doc") || fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("ppt")
	    				|| fileExtension.equalsIgnoreCase("docx")||  fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("pptx")
						|| fileExtension.equalsIgnoreCase("odt") || fileExtension.equalsIgnoreCase("ods") || fileExtension.equalsIgnoreCase("odp") 
						|| fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif") || fileExtension.equalsIgnoreCase("jpg") 
						|| fileExtension.equalsIgnoreCase("jpeg") ||fileExtension.equalsIgnoreCase("bmp")) {
	    			documentUploaded.setPdfFileId(fileId);
	    			documentUploaded.setPdf(false);
				} else if(fileExtension.equalsIgnoreCase("pdf")){
					documentUploaded.setPdf(true);
				} else {
					throw new InternalException("Not a valid file type to support. {pdf|doc|xls|ppt|docx|xlsx|pptx|odt|ods|odp|png|gif|jpg|jpeg|bmp}");
				}
	    		artifactDocuments.add(documentUploaded.getArtifactDocument());
	    	}
			artifact.setArtifactDocuments(artifactDocuments);
			artifact.setApprovalStatus("pending");
			artifact.setModifyCount(1);
			artifactDB = artifactRepository.save(artifact);
			artifactRepository.save(objArtifactDB);
			
			if(artifactDB == null) {
				throw new InternalException("Failed to update artifact {name: " + artifact.getName() + "}");
			}
		} catch(Exception ex) {
			throw new InternalException("Failed to update the artifact.");
		}
		return "1";
	} 
	
	@Override
	public Artifact getArtifactById(String artifactId)
	{
		Artifact artifact = artifactRepository.findOne(artifactId);
		if(artifact == null) {
			throw new InternalException("Artifact record { Id: " + artifactId + "} not found.");
		}
		return artifact;
	}
	
	@Override
	public String approve(WorkflowDetails workflowDetails) {
		
		User uploaderUserDetailsDB;
		User approverUserDetailsDB;

		// 1. Retrieve the artifact to be approved/ rejected. 
		List<Artifact> artifacts  = artifactRepository.findById(workflowDetails.getId());
		if(artifacts == null || artifacts.isEmpty()) {
			throw new InternalException("Artifact record not found.");
		}
		Artifact artifactDb = artifacts.get(0);

		if(artifactDb.getOldArtifactId() != null && artifactDb.getOldArtifactId() !="")
		{
			List<Artifact> oldArtifacts  = artifactRepository.findById(artifactDb.getOldArtifactId());
			if(oldArtifacts == null || oldArtifacts.isEmpty()) {
				throw new InternalException("Failed to find old artifact id.");
			}
			Artifact oldArtifact = oldArtifacts.get(0);
			artifactDb.setLikes(oldArtifact.getLikes());
			artifactDb.setRating(oldArtifact.getRating());
			artifactDb.setRatingCount(oldArtifact.getRatingCount());
			artifactDb.setViews(oldArtifact.getViews());
			artifactDb.setDownloads(oldArtifact.getDownloads());
			artifactDb.setPopularityPercent(oldArtifact.getPopularityPercent());
			artifactRepository.delete(artifactDb.getOldArtifactId());
			userFeedRepository.updateArtifactId(artifactDb.getOldArtifactId(),artifactDb.getId());
		} 

		// 2. Retrieve approver details from the user repository. 
		List<User> approverUsers = userRepository.findByEmployeeId(workflowDetails.getApproverEmployeeId());
		if(approverUsers == null || approverUsers.isEmpty()) {
			throw new InternalException("Approver details { Employee Id: " + workflowDetails.getApproverEmployeeId() + "} not found.");
		}
		approverUserDetailsDB = approverUsers.get(0) ;

		// 3. Call the details of the user who uploaded the app from the user repository to 
		List<User> uploaderUsers = userRepository.findByEmployeeId(artifactDb.getUploaderEmployeeId());
		if(uploaderUsers == null || uploaderUsers.isEmpty()) {
			throw new InternalException("Uploader user details { Employee Id: " + artifactDb.getUploaderEmployeeId() + "}  not found.");
		}
		uploaderUserDetailsDB = uploaderUsers.get(0);

		// 4. Update approver user details in the artifact. 
		artifactDb.setApprovalStatus(workflowDetails.getApprovalStatus());
		artifactDb.setModifyCount(0);
		//artifactDb.setId(artifactDb.getOldArtifactId());
		artifactDb.setApproverId(approverUserDetailsDB.getId());
		artifactDb.setApproverEmployeeId(approverUserDetailsDB.getEmployeeId());
		artifactDb.setApproverName(workflowDetails.getApproverName());
		artifactDb.setApprovalDate(new Date());
		artifactDb.setApproverComments(workflowDetails.getApprovalComments());
		artifactRepository.save(artifactDb);
		
		// 5. Save feed.
		if(workflowDetails.getApprovalStatus().equals("approved")) {
			
			if(artifactDb.getOldArtifactId() != null && artifactDb.getOldArtifactId() !=""){
				UserFeed userFeed = UserFeed.buildUpdated(uploaderUserDetailsDB.getId(), 
						uploaderUserDetailsDB.getEmployeeId(),uploaderUserDetailsDB.getName(),
						artifactDb.getId(),artifactDb.getName());
				userFeedRepository.save(userFeed);
			}
			else{
			UserFeed userFeed = UserFeed.buildUploaded(uploaderUserDetailsDB.getId(), 
				uploaderUserDetailsDB.getEmployeeId(),uploaderUserDetailsDB.getName(),
				artifactDb.getId(),artifactDb.getName());
				userFeedRepository.save(userFeed);
			}
		}
				
		Map<String,Object> templateData = new HashMap<>();
		templateData.put("userName", uploaderUserDetailsDB.getName());
		templateData.put("appName", artifactDb.getName());
		
		if(workflowDetails.getApprovalStatus().equals("approved")) {
			notificationService.send(new PayLoad(uploaderUserDetailsDB.getMailId(),NotificationType.APP_APPROVED,templateData));
		} else {
			templateData.put("rejectionComments", artifactDb.getApproverComments());
			notificationService.send(new PayLoad(uploaderUserDetailsDB.getMailId(),NotificationType.APP_REJECTED,templateData));
		}
		return "1";
	}
	
	public GridFSDBFile retrieveByName(String fileName) {
		return documentRepository.getByFilename(fileName);
	}
	
	public GridFSDBFile retrieveById(String fileId) {
		return documentRepository.getById(fileId);
	}
	
	public UserFeedConsolidated getArtifactDtls(String userId,String artifactId)
	{
		User userDb = userRepository.findById(userId);
		Artifact artifactDb = artifactRepository.findOne(artifactId);
		
		List<UserFeed> userFeeds = userFeedRepository.findAllByUserIdArtifactId(userDb.getId(), artifactDb.getId());
		UserFeedConsolidated userFeedConsolidated = new UserFeedConsolidated();
		userFeedConsolidated.setUserId(userDb.getId());
		userFeedConsolidated.setArtifactId(artifactDb.getId());
		userFeedConsolidated.setRating(userFeedRepository.getAverageRating(artifactDb.getId()).getAvgRating());
		
		if(userFeeds == null || userFeeds.size() ==0) { return userFeedConsolidated; }
		
		for(UserFeed userFeed: userFeeds) {
			switch(userFeed.getUserFeedType()) {
				case LIKED:
					userFeedConsolidated.setLiked(true);
					userFeedConsolidated.setEmployeeId(userFeed.getEmployeeId());
					break;
				case VIEWED:
					userFeedConsolidated.setViewed(true);
					userFeedConsolidated.setEmployeeId(userFeed.getEmployeeId());
					break;
				case DOWNLOADED:
					userFeedConsolidated.setDownloaded(true);
					userFeedConsolidated.setEmployeeId(userFeed.getEmployeeId());
					break;
				case RATING:
					userFeedConsolidated.setRated(true);
					userFeedConsolidated.setUserRating(userFeed.getRating());
					userFeedConsolidated.setEmployeeId(userFeed.getEmployeeId());
					break;
				default:
					break;
			}
		}
		return userFeedConsolidated;
	}
	
	public List<IndividualContributor> getTopContributors() {
		
		// Retrieve top contributors. 
		List<IndividualContributor> topContributors = artifactRepository.findTopContributingIndividuals();

		// Retrieve employee name for each of the contributor.
		for(IndividualContributor individualContributor : topContributors ) {
			String employeeId = individualContributor.getContributorEmployeeId().replaceAll("\\D", "").trim();
			User user = userRepository.findNameByEmployeeId(employeeId);
			individualContributor.setContributorName(user.getName().replace("[", "").replace("]","").replace("\"", "").trim());
			individualContributor.setContributorEmployeeId(employeeId);
			individualContributor.setProfilePicFileId(user.getProfilePicFileId());
		}
		return topContributors;
	}

	public List<BusinessAppCountDto> getTopBusiness() {
		List<BusinessAppCountDto> objBusinessAppCount = artifactRepository.findBusinesswiseAppcount();
		for(BusinessAppCountDto BusinessAppCountObj : objBusinessAppCount)
		{
			String business = BusinessAppCountObj.getBusiness().replace("[", "").replace("]","").replace("\"", "").trim();
			BusinessAppCountObj.setBusiness(business);
		}
		return objBusinessAppCount;
	}
	
	public int getDayDifference(Artifact artifact)
	{
		int diff = 0;
		try{
			diff = Math.round( (System.currentTimeMillis() - artifact.getSubmissionDate().getTime()) / 86400000 );
			// SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
			// diff = (int) Math.round((simpleDateFormat.parse(simpleDateFormat.format(new Date())).getTime() - simpleDateFormat.parse(simpleDateFormat.format(artifact.getSubmissionDate())).getTime()) / (double) 86400000);
		}catch(Exception e){
			return 0;
		}
		return diff;
	}
	
	public List<Artifact> getLatestApps() {
		List<Artifact> artifactList = artifactRepository.findByApprovalStatus("approved");
		List<Artifact> artifactList1 = new ArrayList<>();
		for(Artifact artifact : artifactList)
		{
			artifact.setDayDiff(getDayDifference(artifact));
			artifactList1.add(artifact);
		}
		artifactList1.sort((p1,p2) -> p2.getSubmissionDate().compareTo(p1.getSubmissionDate()));
		return artifactList1;
	}
	
	public List<Artifact> findByApprovalStatus(String approvalStatus)
	{
		List<Artifact> lstArtifact = artifactRepository.findByApprovalStatus(approvalStatus);
		lstArtifact.sort((p1,p2) -> p1.getName().compareTo(p2.getName()));
		return lstArtifact;
	}
}
