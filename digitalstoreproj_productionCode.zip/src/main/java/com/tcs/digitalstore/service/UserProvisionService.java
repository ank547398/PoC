package com.tcs.digitalstore.service;


import org.springframework.web.multipart.MultipartFile;

import com.tcs.digitalstore.domain.GeMatixUserDetails;
import com.tcs.digitalstore.domain.User;

/**
 * Interface for User Provisioning Services. 
 * @author 1253182
 *
 */
public interface UserProvisionService {
	/**
	 * Handles the registration request from the user. 
	 * 		The call is delegated to repository for persisting the user details.
	 * 		Mail alert to relevant stake holders.   
	 * @param userDet holds details of the user registration
	 * @return error/ success code of type String 
	 * @see User
	 */
	String register(GeMatixUserDetails geMatixUserDetails);
	
	/**
	 * Service method for approval/ rejection of the user registration request. 
	 * 		Approval/ rejection of the user registration request.
	 * 		Mail alert to relevant stake holders. 
	 * @param userDet 
	 * @return error/ success code of type String
	 * @see User
	 */
	String approve(User userDet);
	
	/**
	 * Service method for uploading profile pic. 
	 * @param employeeId
	 * @param profilePic
	 * @return
	 */
	String uploadProfilePic(String employeeId,MultipartFile profilePic);
}
