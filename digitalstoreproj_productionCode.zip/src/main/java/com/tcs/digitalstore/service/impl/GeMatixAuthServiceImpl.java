package com.tcs.digitalstore.service.impl;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.tcs.digitalstore.domain.GeMatixUserDetails;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.service.GeMatixAuthService;

@Component
public class GeMatixAuthServiceImpl implements GeMatixAuthService {
	@Autowired private PasswordEncoder passwordEncoder;

	private RestTemplate createRestTemplate() {
		final String proxyUrl = "http-proxy.em.health.ge.com";
        final int port = 88;
        HttpHost myProxy = new HttpHost(proxyUrl, port);
        HttpClientBuilder clientBuilder = HttpClientBuilder.create();
        clientBuilder.setProxy(myProxy).disableCookieManagement();
        HttpClient httpClient = clientBuilder.build();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setHttpClient(httpClient);
        return new RestTemplate(factory);
	}
	
	@Override
	public GeMatixUserDetails authenticate(String userName, String userPassword) {
		
		RestTemplate restTemplate = createRestTemplate();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			String requestJson = "{\"userId\":\""+userName + "\",\"password\":\""+userPassword + "\"}";
			HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
			GeMatixUserDetails geMatixUserDetails = restTemplate.postForObject("http://52.20.152.15:8085/api/authenticatelink", entity, GeMatixUserDetails.class);
			if(geMatixUserDetails.getUserName() == null || geMatixUserDetails.getUserName().isEmpty() ||
					geMatixUserDetails.getUserId() == null || geMatixUserDetails.getUserId().isEmpty()) {
				throw new InternalException("Authentication Failed. Invalid Username/ password.");
			}
			geMatixUserDetails.setDigest(passwordEncoder.encode(geMatixUserDetails.toString()));
			return geMatixUserDetails;
		}catch(HttpStatusCodeException  ex) {
			throw new BadCredentialsException("Invalid Credentials.",ex);
			// HttpClientErrorException and/or the HttpServerErrorException
		} 
	}
	
	
}
