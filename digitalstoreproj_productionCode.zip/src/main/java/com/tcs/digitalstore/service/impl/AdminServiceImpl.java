package com.tcs.digitalstore.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.digitalstore.domain.Admin;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.repository.ArtifactRepository;
import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	
	@Autowired UserRepository userRepository;
	@Autowired ArtifactRepository artifactRepository;
	
	public List<Admin> searchAllUsers()
	{
		List<User> userLst = userRepository.findAll();
		List<Admin> adminLst = new ArrayList<Admin>();
		for(User objUser : userLst)
		{
			Admin objAdmin = new Admin();
			objAdmin.setApprovalStatus(objUser.getApprovstatus());
			objAdmin.setBusinessUnit(objUser.getBusinessUnit());
			objAdmin.setEmailId(objUser.getMailId());
			objAdmin.setEmployeeId(objUser.getEmployeeId());
			objAdmin.setUserId(objUser.getId());
			objAdmin.setFullName(objUser.getName());
			objAdmin.setRole(objUser.getRole());
			objAdmin.setApprovalDate(objUser.getApprovalDate());
			objAdmin.setApproverId(objUser.getApproverEmployeeId());
			objAdmin.setApproverName(objUser.getApproverEmployeeName());
			adminLst.add(objAdmin);			
		}
		
		return adminLst;
	}
	
	public String updateUsers(Admin objAdmin)
	{
		List<User> lstUser = userRepository.findByEmployeeId(objAdmin.getEmployeeId());
		if(lstUser.size()==0)
		{
			return "0";
		}
		
		User objUser = userRepository.findById(objAdmin.getUserId());

		objUser.setEmployeeId(objAdmin.getEmployeeId());
		objUser.setId(objAdmin.getUserId());
		objUser.setRole(objAdmin.getRole());
		objUser.setApprovstatus(objAdmin.getApprovalStatus());
		objUser.setName(objAdmin.getFullName());
		objUser.setBusinessUnit(objAdmin.getBusinessUnit());
		userRepository.save(objUser);
		return "1";
	}
	
	public String deleteUsers(String userId)
	{
		User lstUser = userRepository.findById(userId);
		if(lstUser == null)
		{
			return "0";
		}
		
		userRepository.delete(userId);
		return "1";
	}
	
	public List<Artifact> searchAllArtifacts() {
		return artifactRepository.findAll();
	}
	
	public String deleteArtifact(String artifactId) {
		Artifact objArtifact = artifactRepository.findOne(artifactId);
		if(objArtifact == null || objArtifact.getModifyCount() == 1)
		{
			return "0";
		}
		
		artifactRepository.delete(artifactId);
		return "1";
	}

}
