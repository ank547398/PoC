package com.tcs.digitalstore.security;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.tcs.digitalstore.domain.User;

public class DigiUser implements UserDetails {

    private static final long serialVersionUID = 4101612704050704117L;
	private final String id;
	private final String employeeId;
	private final String name;
	private final String email;
    private final String role;
    private final String profilePicId;
    private final boolean enabled;
	private final Collection<? extends GrantedAuthority> authorities;
    
	public DigiUser(String id,String employeeId,String name,String email,
						String role,Collection<? extends GrantedAuthority> authorities,boolean enabled,String profilePicId) {
        this.id = id;
        this.name = name;
        this.employeeId = employeeId;
        this.email = email;
        this.authorities = authorities;
        this.role = role;
        this.enabled = enabled;
        this.profilePicId = profilePicId;
    }
    
    public DigiUser(User user) {
		this.id = user.getId();
		this.employeeId = user.getEmployeeId();
		this.name = user.getName();
		this.email = user.getMailId();
		this.authorities = Arrays.asList(new SimpleGrantedAuthority(user.getRole().toUpperCase()));
		this.role = user.getRole();
		this.enabled = user.getApprovstatus().equals("approved") ? true: false;
		this.profilePicId = user.getProfilePicFileId();
	}

	public String getId() {
        return id;
    }

    @Override
    public String getUsername() {
        return employeeId;
    }
    
    @Override
    public String getPassword() {
    	return "";
    }
    

    @JsonIgnore
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @JsonIgnore
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @JsonIgnore
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    public String getName() {
        return name;
    }

    public String getEmployeeId() {
        return employeeId;
    }
    
    public String getEmail() {
        return email;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }
    
    public String getProfilePicId() {
    	return this.profilePicId;
    }
    public String getRole() {
    	return this.role;
    }
}
