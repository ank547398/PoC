package com.tcs.digitalstore.security;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.lang.String;
import com.tcs.digitalstore.security.SessionEntity;
import java.util.List;


public interface SessionEntityRepository extends MongoRepository<SessionEntity, String>,SessionEntityRepositoryCustom {
		List<SessionEntity> findByUserName(String username);
}
