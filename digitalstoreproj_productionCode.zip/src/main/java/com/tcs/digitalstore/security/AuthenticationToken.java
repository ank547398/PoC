package com.tcs.digitalstore.security;
import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

@SuppressWarnings("serial")
public class AuthenticationToken implements Authentication {
	
	private String userId;
	private Collection<? extends GrantedAuthority> authorities;
	private boolean authenticated;
	private DigiUser digiUser;
	
	public AuthenticationToken(String userId,Collection<? extends GrantedAuthority> authorities,
			boolean authenticated,DigiUser digiUser) {
		this.userId = userId;
		this.authorities = authorities;
		this.authenticated = authenticated;
		this.digiUser = digiUser;
		
	}
	
	@Override
	public String getName() {
		return userId;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public Object getCredentials() {
		return null;
	}

	@Override
	public Object getDetails() {
		return digiUser;
	}

	@Override
	public Object getPrincipal() {
		return userId;
	}

	@Override
	public boolean isAuthenticated() {
		return authenticated;
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub
		
	}

}
