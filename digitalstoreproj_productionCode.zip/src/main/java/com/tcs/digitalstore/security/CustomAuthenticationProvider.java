package com.tcs.digitalstore.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AccountStatusException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.GeMatixUserDetails;
import com.tcs.digitalstore.service.impl.GeMatixAuthServiceImpl;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
	@Autowired GeMatixAuthServiceImpl geMatixAuthServiceImpl;
	@Autowired private UserDetailsService userDetailsService;
	
	@SuppressWarnings("serial")
	public Authentication authenticate(Authentication authentication ) throws AuthenticationException {
		String userName = authentication.getName().trim();
        String password = authentication.getCredentials().toString().trim();

        DigiUser userDetails = (DigiUser) userDetailsService.loadUserByUsername(userName);
        if(! userDetails.isEnabled()) {
        	throw new AccountStatusException("Registration request is pending for approval.") {
			};
        }
        
        GeMatixUserDetails geMatixUserDetails = geMatixAuthServiceImpl.authenticate(userName, password);
        return new AuthenticationToken(geMatixUserDetails.getUserId(), userDetails.getAuthorities(), true, userDetails);
	}
	
	
	
	@Override
    public boolean supports(Class<? extends Object> authentication) {
        return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
    }
}
