package com.tcs.digitalstore.security;

public interface SessionEntityRepositoryCustom {
	public void deleteByUserName(String userName);
}
