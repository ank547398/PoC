package com.tcs.digitalstore.security;

import org.springframework.security.core.userdetails.UserDetails;

public class AuthenticationResponse {
	private final String token;
	private final UserDetails userDetails;
    public AuthenticationResponse(String token,UserDetails userDetails) {
        this.token = token;
        this.userDetails = userDetails;
    }
    public String getToken() {
        return this.token;
    }
    public UserDetails getUserDetails() {
    	return this.userDetails;
    }
}
