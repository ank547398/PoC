package com.tcs.digitalstore.security;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="sessionEntities")
public class SessionEntity {
	private String id;
	
	@Indexed(unique=true)
	private String userName;
	
	private long creationTime;
	
	private long expirationTime;
	
	private String tokenIssued;
	
	private String proxyIp;
	
	
	/**
	 * @param userName
	 * @param creationTime
	 * @param expirationTime
	 * @param tokenIssued
	 * @param proxyIp
	 */
	public SessionEntity(String userName, long creationTime,
			long expirationTime, String tokenIssued, String proxyIp) {
		super();
		this.userName = userName;
		this.creationTime = creationTime;
		this.expirationTime = expirationTime;
		this.tokenIssued = tokenIssued;
		this.proxyIp = proxyIp;
	}

	public String getId() {
		return id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(long creationTime) {
		this.creationTime = creationTime;
	}

	public long getExpirationTime() {
		return expirationTime;
	}

	public void setExpirationTime(long expirationTime) {
		this.expirationTime = expirationTime;
	}

	public String getTokenIssued() {
		return tokenIssued;
	}

	public void setTokenIssued(String tokenIssued) {
		this.tokenIssued = tokenIssued;
	}

	public String getProxyIp() {
		return proxyIp;
	}

	public void setProxyIp(String proxyIp) {
		this.proxyIp = proxyIp;
	}
}
