package com.tcs.digitalstore.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.SessionData;
import com.tcs.digitalstore.repository.SessionRepository;

@Component
public class TokenHandler {
	private static final String CLAIM_KEY_USERNAME = "sub";
    private static final String CLAIM_KEY_CREATED = "created";
    @Autowired private SessionRepository sessionRepository;
    
    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private Long expiration;
    
    public String getUsernameFromToken(String token) {
        String username;
        try {
            final Claims claims = getClaimsFromToken(token);
            username = claims.getSubject();
        } catch (Exception e) {
            username = null;
        }
        return username;
    }

    public Date getCreatedDateFromToken(String token) {
        Date created;
        try {
            final Claims claims = getClaimsFromToken(token);
            created = new Date((Long) claims.get(CLAIM_KEY_CREATED));
        } catch (Exception e) {
            created = null;
        }
        return created;
    }

    public Date getExpirationDateFromToken(String token) {
        Date expiration;
        try {
            final Claims claims = getClaimsFromToken(token);
            expiration = claims.getExpiration();
        } catch (Exception e) {
            expiration = null;
        }
        return expiration;
    }

   private Claims getClaimsFromToken(String token) {
        Claims claims;
        try {
            claims = Jwts.parser()
                    .setSigningKey(secret)
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            claims = null;
        }
        return claims;
    }

   /*
    public Date generateExpirationDate() {
        return new Date(System.currentTimeMillis() + (expiration * 60 *1000));
    }*/

    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }
    
    private Boolean isTokenExpired(SessionData sessionData) {
    	System.out.println("Expiry time: " + sessionData.getExpiryDateTime() + ",Current Time: " + System.currentTimeMillis());
    	long expirationDateTime = sessionData.getExpiryDateTime();
    	if(expirationDateTime < System.currentTimeMillis()) 
    		return true;
    	return false;
    }

    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        claims.put(CLAIM_KEY_USERNAME, userDetails.getUsername());
        claims.put(CLAIM_KEY_CREATED, new Date());
        String token = generateToken(claims);
        sessionRepository.save(new SessionData(token,userDetails.getUsername(),
        		System.currentTimeMillis(), System.currentTimeMillis() + (expiration*60*1000)) );
        System.out.println("******** Token Issued: " + System.currentTimeMillis() + ", Expiry: " + System.currentTimeMillis() + (expiration*60*1000));
        return token;
    }

    private String generateToken(Map<String, Object> claims) {
       String token= Jwts.builder()
                		.setClaims(claims)
                		// .setExpiration(generateExpirationDate())
                		.signWith(SignatureAlgorithm.HS512, secret)
                		.compact();
       return token;
    }

    public Boolean canTokenBeRefreshed(String token) {
        return (!isTokenExpired(token) );
    }

    public String refreshToken(String token) {
        String refreshedToken;
        try {
            final Claims claims = getClaimsFromToken(token);
            claims.put(CLAIM_KEY_CREATED, new Date());
            refreshedToken = generateToken(claims);
        } catch (Exception e) {
            refreshedToken = null;
        }
        return refreshedToken;
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
    	List<SessionData> listSessionData = sessionRepository.findByTokenIssued(token);
    	if(listSessionData == null || listSessionData.isEmpty()) {
    		throw new SessionAuthenticationException("Invalid Session");
    	}
    	SessionData sessionData = listSessionData.get(0);
    	String username = getUsernameFromToken(token);
        if(username.equals(userDetails.getUsername()) 
        		&& username.equals(sessionData.getUserName()) 
        		&& !isTokenExpired(sessionData)){
        	sessionData.setExpiryDateTime(System.currentTimeMillis() + (expiration*60*1000));   //Original line
        	System.out.println("Expiration DateTime" + sessionData.getExpiryDateTime());
        	//sessionData.setExpiryDateTime(expiration*60*1000);
        	sessionRepository.save(sessionData);
        	return true;
        } 
        return false;
    }
}
