package com.tcs.digitalstore;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurerAdapter;

import com.tcs.digitalstore.controller.UserFeeds;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.ArtifactDocument;
import com.tcs.digitalstore.domain.User;

@Configuration
public class SpringDataRestConfig {
	@Bean
    public RepositoryRestConfigurer repositoryRestConfigurer() {

        return new RepositoryRestConfigurerAdapter() {
            @Override
            public void configureRepositoryRestConfiguration(
                                 RepositoryRestConfiguration config) {
                config.exposeIdsFor(Artifact.class, User.class,ArtifactDocument.class,UserFeeds.class);
            }
        };

    }
}
