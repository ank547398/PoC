package com.tcs.digitalstore.exceptions;

@SuppressWarnings("serial")
public class InternalException extends RuntimeException{
	
	public InternalException(String message,Throwable t) {
		super(message,t);
	}
	
	public InternalException(String message) {
		super(message);
	}
}
