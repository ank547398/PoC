package com.tcs.digitalstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.tcs.digitalstore.security.CustomAuthenticationProvider;
import com.tcs.digitalstore.security.DigiAuthenticationEntryPoint;
import com.tcs.digitalstore.security.DigiAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
    private CustomAuthenticationProvider customAuthenticationProvider;
	
    @Autowired
    private DigiAuthenticationEntryPoint unauthorizedHandler;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    public void configureAuthentication(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder.
        				authenticationProvider(customAuthenticationProvider);
        				// .userDetailsService(this.userDetailsService);
                
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
    	return new BCryptPasswordEncoder();
    	// return new BCryptPasswordEncoder();
    }
    
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public DigiAuthenticationFilter authenticationTokenFilterBean() throws Exception {
    	DigiAuthenticationFilter authenticationTokenFilter = new DigiAuthenticationFilter();
        authenticationTokenFilter.setAuthenticationManager(authenticationManagerBean());
        return authenticationTokenFilter;
    }
    
    /*@Bean
    public DaoAuthenticationProvider authProvider() {
     // LimitLoginAuthenticationProvider is my own class which extends DaoAuthenticationProvider 
        final DaoAuthenticationProvider authProvider = new LimitLoginAuthenticationProvider(); 
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }*/
    

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                // we don't need CSRF because our token is invulnerable
                .csrf().disable()
                .exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                .authorizeRequests()
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .antMatchers("/authentication/login").permitAll()
                .antMatchers("/user/register").permitAll()
                .antMatchers("/user/confirm").permitAll()
                .antMatchers("/artifact/getlogo/**").permitAll()
                .antMatchers("/artifact/hello").permitAll()
                .antMatchers("/document/downloadbyid/**").permitAll()
                .anyRequest().authenticated();

        // Custom JWT based security filter
        httpSecurity.addFilter(authenticationTokenFilterBean());
        /// httpSecurity.addFilterBefore(, UsernamePasswordAuthenticationFilter.class);
        // httpSecurity.addFilterBefore(authenticationTokenFilterBean());
        // disable page caching
        httpSecurity.headers().cacheControl();
    }
}
