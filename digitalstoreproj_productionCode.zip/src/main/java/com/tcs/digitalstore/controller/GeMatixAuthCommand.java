package com.tcs.digitalstore.controller;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

public class GeMatixAuthCommand {

	@NotEmpty(message="Employee Id cannot be null or empty.")
	@Pattern(regexp="\\d{3,10}",message="Only digits are allowed in Employee Id {Minimum 3 digits and Maximum 10 digits}.")
	private String employeeId;
	
	@NotEmpty(message="Password cannot be null or empty.")
	@Length(min=3,max=16,message="Password can have minimum 3 and maximum 16 characters.")
	@Pattern(regexp="[A-Za-z0-9!@#$%^&*]+",message="Provide valid password.")
	private String userPass;
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
}
