package com.tcs.digitalstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.domain.UserFeedToDisplay;
import com.tcs.digitalstore.domain.validationchecks.UserFeedChecks;
import com.tcs.digitalstore.domain.validationchecks.UserFeedRatingChecks;
import com.tcs.digitalstore.repository.AvgRating;
import com.tcs.digitalstore.repository.UserFeedRepository;
import com.tcs.digitalstore.service.UserFeedService;

@RestController
@RequestMapping(path="/userfeed")
public class UserFeeds {
	
	@Autowired private UserFeedService userFeedService;
	@Autowired private UserFeedRepository userFeedRepository; 

	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/like", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public @ResponseBody String like(@RequestBody @Validated(value={UserFeedChecks.class}) UserFeed userFeed) {
		return userFeedService.like(userFeed.getUserId(),userFeed.getArtifactId());
	}   
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/unlike", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public @ResponseBody String unlike(@RequestBody @Validated(value={UserFeedChecks.class}) UserFeed userFeed) {
		return userFeedService.unlike(userFeed.getUserId(),userFeed.getArtifactId());
	} 
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/view", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public String view(@RequestBody @Validated(value={UserFeedChecks.class}) UserFeed userFeed) {
		return userFeedService.view(userFeed.getUserId(),userFeed.getArtifactId());
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/download", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public String download(@RequestBody @Validated(value={UserFeedChecks.class}) UserFeed userFeed) {
		return userFeedService.download(userFeed.getUserId(),userFeed.getArtifactId());
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/rating", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public AvgRating rating(@RequestBody @Validated(value={UserFeedRatingChecks.class}) UserFeed userFeed) {
		return userFeedService.rating(userFeed.getUserId(),userFeed.getArtifactId(),userFeed.getRating());
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/get", method=RequestMethod.GET,produces="application/json")
    public List<UserFeedToDisplay> getUserFeeds() {
    	return userFeedRepository.getFeeds();
    }
}
