 package com.tcs.digitalstore.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.HtmlUtils;

import com.mongodb.gridfs.GridFSDBFile;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.BusinessAppCountDto;
import com.tcs.digitalstore.domain.ContactPerson;
import com.tcs.digitalstore.domain.DocumentUploaded;
import com.tcs.digitalstore.domain.IndividualContributor;
import com.tcs.digitalstore.domain.UserFeedConsolidated;
import com.tcs.digitalstore.domain.WorkflowDetails;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.ArtifactRepository;
import com.tcs.digitalstore.repository.DocumentRepository;
import com.tcs.digitalstore.service.ArtifactService;
import com.tcs.digitalstore.utility.mailer.NotificationService;

@RestController
@RequestMapping(path="/artifact")
public class Artifacts {
	
	@Autowired private ArtifactService artifactService;
	
	@Autowired private DocumentRepository documentRepository;
	
	@Autowired private ArtifactRepository artifactRepository;
	
	private static final int MAX_FILES_ALLOWED_TO_UPLOAD = 6;
	
	private static final int MAX_CONTACTS_ALLOWED_TO_ADD = 2;
	
	@Autowired NotificationService notificationService;
	
	@PreAuthorize("hasAnyAuthority('ADMIN','MANAGER')")
	@RequestMapping(value="/add", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody String add(
    		@RequestParam("name")				String name,
    		@RequestParam("promoText")			String promoText,
    		@RequestParam("solution")			String solution,
    		@RequestParam("version")			String version,
    		@RequestParam("business")			String business,
    		@RequestParam("businessbenefit")	String businessbenefit,
    		@RequestParam("category")			String category,
    		@RequestParam("functions")			String [] functions,
    		@RequestParam("appType")			String appType,
    		@RequestParam("uploaderEmployeeId")	String uploaderEmployeeId,
    		@RequestParam("uploaderUserName")	String uploaderUserName,
    		@RequestParam("submissionDate")		String submissionDate,
    		@RequestParam("employeeId")			List<String> employeeId,
    		@RequestParam("employeeName")		List<String> employeeName,
    		@RequestParam("mailId")				List<String> mailId,
    		@RequestParam("role")				List<String> role,
    		@RequestParam("uploadedFiles") 		List<MultipartFile> uploadedFiles,
    		@RequestParam("displayName")		List<String> displayNames,
    		@RequestParam("documentTypes") 		List<String> documentTypes,
    		@RequestParam("contentTypes") 		List<String> contentTypes)  throws MethodArgumentNotValidException {
    	
		Artifact artifact = new Artifact();
		artifact.setName(name);
		artifact.setPromoText(promoText);
		artifact.setSolution(solution);
		artifact.setVersion(version);
		artifact.setBusiness(business);
		artifact.setBusinessbenefit(businessbenefit);
		artifact.setCategory(category);
		artifact.setAppType(appType);
		
		
		if(functions.length > 10) {
			throw new InternalException("Select maximum 10 technologies.");
		}
		List<String> techstack = new ArrayList<>();
		for(int i=0; i < functions.length;i++) {
			techstack.add(functions[i]);
		}
		artifact.setFunctions(techstack);

		
		artifact.setSubmissionDate(new Date());
		artifact.setUploaderEmployeeId(uploaderEmployeeId);
		artifact.setUploaderUserName(uploaderUserName);

		artifact.setApprovalStatus("pending");
		
		List<ContactPerson> contactPersons = new ArrayList<ContactPerson>();
		for(int i=0; i < MAX_CONTACTS_ALLOWED_TO_ADD ; i++)
		{
			if(employeeName.get(i) == null || employeeName.get(i).isEmpty() || 
					employeeId.get(i) == null || 	employeeId.get(i).isEmpty()) {
				continue;
			}
			ContactPerson objContactPerson = new ContactPerson();
			objContactPerson.setRole(role.get(i));
			objContactPerson.setEmployeeId(employeeId.get(i));
			objContactPerson.setEmployeeName(employeeName.get(i));
			objContactPerson.setMailId(mailId.get(i));
			contactPersons.add(objContactPerson);
		}
		artifact.setContactPersons(contactPersons);
   		List<DocumentUploaded> documentsUploaded = new ArrayList<>();
   		int noOfFiles = (uploadedFiles.size() < MAX_FILES_ALLOWED_TO_UPLOAD) ? uploadedFiles.size() : MAX_FILES_ALLOWED_TO_UPLOAD;
   			
   		for(int i=0 ; i < noOfFiles ; i++){
    		DocumentUploaded documentUploaded = new DocumentUploaded();
    		documentUploaded.setDocument(uploadedFiles.get(i));
    		documentUploaded.setDisplayName(displayNames.get(i));
    		documentUploaded.setDocumentType(documentTypes.get(i));
    		documentUploaded.setContentType(contentTypes.get(i));
    		documentUploaded.setFileName(uploadedFiles.get(i).getOriginalFilename());
    		documentsUploaded.add(documentUploaded);
    	}
    	return artifactService.add(artifact,documentsUploaded);
    	
    	
    			
    }
	
	@PreAuthorize("hasAnyAuthority('ADMIN','MANAGER')")
	@RequestMapping(value="/update", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody String update(
    		@RequestParam("name")				String name,
    		@RequestParam("artifactId")			String artifactId,
    		@RequestParam("promoText")			String promoText,
    		@RequestParam("solution")			String solution,
    		@RequestParam("version")			String version,
    		@RequestParam("business")			String business,
    		@RequestParam("businessbenefit")	String businessbenefit,
    		@RequestParam("category")			String category,
    		@RequestParam("functions")			String [] functions,
    		@RequestParam("appType")			String appType,
    		@RequestParam("uploaderEmployeeId")	String uploaderEmployeeId,
    		@RequestParam("uploaderUserName")	String uploaderUserName,
    		@RequestParam("submissionDate")		String submissionDate,
    		@RequestParam("employeeId")			List<String> employeeId,
    		@RequestParam("employeeName")		List<String> employeeName,
    		@RequestParam("mailId")				List<String> mailId,
    		@RequestParam("role")				List<String> role,
    		@RequestParam("deletedFileId")		List<String> deletedFileId, 
    		@RequestParam("uploadedFiles") 		List<MultipartFile> uploadedFiles,
    		@RequestParam("displayName")		List<String> displayNames,
    		@RequestParam("documentTypes") 		List<String> documentTypes,
    		@RequestParam("contentTypes") 		List<String> contentTypes)  throws MethodArgumentNotValidException {

		Artifact artifact = new Artifact();
		artifact.setName(name);
		artifact.setPromoText(promoText);
		artifact.setSolution(solution);
		artifact.setVersion(version);
		artifact.setBusiness(business);
		artifact.setBusinessbenefit(businessbenefit);
		artifact.setCategory(category);
		artifact.setAppType(appType);

		if(functions.length > 10) {
			throw new InternalException("Select maximum 10 technologies.");
		}
		List<String> techstack = new ArrayList<>();
		for(int i=0; i < functions.length;i++) {
			techstack.add(functions[i]);
		}		
		artifact.setFunctions(techstack);

		artifact.setSubmissionDate(new Date());
		artifact.setUploaderEmployeeId(uploaderEmployeeId);
		artifact.setUploaderUserName(uploaderUserName);
		artifact.setApprovalStatus("pending");

		List<ContactPerson> contactPersons = new ArrayList<ContactPerson>();
		for(int i=0; i < MAX_CONTACTS_ALLOWED_TO_ADD ; i++)
		{
			if(employeeName.get(i) == null || employeeName.get(i).isEmpty() || 
					employeeId.get(i) == null || 	employeeId.get(i).isEmpty()) {
				continue;
			}
			ContactPerson objContactPerson = new ContactPerson();
			objContactPerson.setRole(role.get(i));
			objContactPerson.setEmployeeId(employeeId.get(i));
			objContactPerson.setEmployeeName(employeeName.get(i));
			objContactPerson.setMailId(mailId.get(i));
			contactPersons.add(objContactPerson);
		}
		artifact.setContactPersons(contactPersons);

		List<DocumentUploaded> documentsUploaded = new ArrayList<>();
   		int noOfFiles = (uploadedFiles.size() < MAX_FILES_ALLOWED_TO_UPLOAD) ? uploadedFiles.size() : MAX_FILES_ALLOWED_TO_UPLOAD;

   		for(int i=0 ; i < noOfFiles ; i++){
    		DocumentUploaded documentUploaded = new DocumentUploaded();
    		documentUploaded.setDocument(uploadedFiles.get(i));
    		documentUploaded.setDisplayName(displayNames.get(i));
    		documentUploaded.setDocumentType(documentTypes.get(i));
    		documentUploaded.setContentType(contentTypes.get(i));
    		documentUploaded.setFileName(uploadedFiles.get(i).getOriginalFilename());
    		documentsUploaded.add(documentUploaded);
    	}

		artifact.setOldArtifactId(artifactId);
		artifact.setDeletedFileId(deletedFileId);

    	return artifactService.update(artifact,documentsUploaded);
    } 
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value="/approve", method=RequestMethod.POST,produces="application/json")
	public String approve(@RequestBody WorkflowDetails workFlowDetails) {
		return artifactService.approve(workFlowDetails);
	}
	
	@RequestMapping(value="/hello", method=RequestMethod.GET,produces="application/json")
	public String hello() {
		return "hello";
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/findbyid", method=RequestMethod.GET,produces="application/json")
    public Artifact getArtifactById(@RequestParam("artifactId") String artifactId) {
		
		
		if(artifactId == null || artifactId.isEmpty()) {
			throw new InternalException("Artifact id cannot be empty or null.");
		}
		if(! artifactId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Please provide valid artifact id.");
		}
    	return artifactService.getArtifactById(artifactId);
    }
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/getconsfeed", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserFeedConsolidated getArtifactDtls(@RequestParam String userId,@RequestParam String artifactId) {
		
		if(userId == null || userId.isEmpty() || ! userId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Valid user id is mandatory.");
		}
		
		if(artifactId == null || artifactId.isEmpty() || ! artifactId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Valid artifact id is mandatory.");
		}

		userId = HtmlUtils.htmlEscape(userId);
		artifactId = HtmlUtils.htmlEscape(artifactId);
		
		return artifactService.getArtifactDtls(userId,artifactId);
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/gettopcontributors", method=RequestMethod.GET,produces="application/json")
    public List<IndividualContributor> getTopContributors() {
    	return artifactService.getTopContributors();
    }
    
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
    @RequestMapping(value="/gettopbusiness", method=RequestMethod.GET,produces="application/json")
    public List<BusinessAppCountDto> getTopBusiness() {
    	return artifactService.getTopBusiness();
    }
    
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
    @RequestMapping(value="/getlatestapps", method=RequestMethod.GET,produces="application/json")
    public List<Artifact> getLatestApps() {
    	return artifactService.getLatestApps();
    }
		
	@RequestMapping(value = "/getlogo/{fileID}", method = RequestMethod.GET)
	public void getFilebyId(@PathVariable("fileID") String fileId,HttpServletResponse response) throws IOException {
		if(fileId == null || fileId.isEmpty() || ! fileId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Provide valid non empty non null file id.");
		}
		GridFSDBFile gridfsFile = documentRepository.getById(fileId);
	    IOUtils.copy(gridfsFile.getInputStream(), response.getOutputStream());
	    response.flushBuffer();
	}
	
	@RequestMapping(value = "/admin/findByAdminApprovalStatus", method = RequestMethod.GET)
	public List<Artifact> getAdminApps(String approvalStatus,String userId) {
		return artifactRepository.findByAdminApprovalStatus(approvalStatus, userId);
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value = "/search/findByApprovalStatus", method = RequestMethod.GET)
	public List<Artifact> getApprovedApps(@Param("approvalStatus")String approvalStatus) {
		return artifactService.findByApprovalStatus(approvalStatus);
	}
}
