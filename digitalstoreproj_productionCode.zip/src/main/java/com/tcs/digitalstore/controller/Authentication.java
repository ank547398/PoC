package com.tcs.digitalstore.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.security.AuthenticationResponse;
import com.tcs.digitalstore.security.AuthenticationToken;
import com.tcs.digitalstore.security.DigiUser;
import com.tcs.digitalstore.security.TokenHandler;
import com.tcs.digitalstore.utility.DigitalStoreUtility;

@Controller
@RequestMapping(path="/authentication")
public class Authentication {
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired private UserRepository userRepository;
	
	@Autowired private AuthenticationManager authenticationManager;
	
	@Autowired private UserDetailsService userDetailsService;
	
	@Autowired private TokenHandler jwtTokenUtil;
	
	@Value("${jwt.expiration}")
	private Long expiration;
	
	@Value("${jwt.header}")
	private String tokenHeader;
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ResponseEntity<?> login(@Validated @RequestBody GeMatixAuthCommand geMatixAuthCommand,HttpServletRequest request){
		final AuthenticationToken authentication = (AuthenticationToken) authenticationManager.authenticate(
												                new UsernamePasswordAuthenticationToken(
												                		geMatixAuthCommand.getEmployeeId(),
												                		geMatixAuthCommand.getUserPass()
												                )
											);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		final String token 				= DigitalStoreUtility.sanitize(jwtTokenUtil.generateToken((DigiUser) authentication.getDetails()));
        // final String token 				= jwtTokenUtil.generateToken((DigiUser) authentication.getDetails());
        return ResponseEntity.ok(new AuthenticationResponse(token,(DigiUser) authentication.getDetails()));
    }
	
	/*
	private String getRemoteAddr(HttpServletRequest request) {
		if (request.getHeader("X-FORWARDED-FOR") != null && ! request.getHeader("X-FORWARDED-FOR").isEmpty()) {  
            return request.getHeader("X-FORWARDED-FOR");  
        }
        return request.getRemoteAddr();
	}*/
	
	/*
	@RequestMapping(value = "/refresh", method = RequestMethod.GET)
    public ResponseEntity<?> refreshAndGetAuthenticationToken(HttpServletRequest request) {
        String token = DigitalStoreUtility.sanitize(request.getHeader(tokenHeader));
        String username = jwtTokenUtil.getUsernameFromToken(token);
        
        DigiUser user = (DigiUser) userDetailsService.loadUserByUsername(username);
        if (jwtTokenUtil.canTokenBeRefreshed(token)) {
            String refreshedToken = jwtTokenUtil.refreshToken(token);
            return ResponseEntity.ok(new AuthenticationResponse(refreshedToken,user));
        } else {
            return ResponseEntity.badRequest().body(null);
        }
    }*/
}
