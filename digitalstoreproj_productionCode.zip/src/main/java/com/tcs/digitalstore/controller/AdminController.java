package com.tcs.digitalstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.digitalstore.domain.Admin;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.service.AdminService;


@RestController
@RequestMapping(path="/admin")
public class AdminController {
	
	@Autowired private AdminService adminService;
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value="/searchAllUsers", method=RequestMethod.GET,produces="application/json")
	public List<Admin> searchAllUsers() {
		return adminService.searchAllUsers();
	}
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value="/updateUsers", method=RequestMethod.POST,produces="application/json")
	public String updateUsers(
			@RequestParam("userId") String userId,
			@RequestParam("employeeId") String employeeId,
			@RequestParam("fullName") String fullName,
			@RequestParam("approvalStatus") String approvalStatus,
			@RequestParam("role") String role,
			@RequestParam("businessUnit") String businessUnit) {
		
		Admin objAdmin = new Admin();
		objAdmin.setUserId(userId);
		objAdmin.setEmployeeId(employeeId);
		objAdmin.setFullName(fullName);
		objAdmin.setApprovalStatus(approvalStatus);
		objAdmin.setRole(role);
		objAdmin.setBusinessUnit(businessUnit);
		
		return adminService.updateUsers(objAdmin);
	}
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value="/deleteUsers", method=RequestMethod.POST,produces="application/json")
	public String deleteUsers(@RequestBody	String userId) {
		String userId1 = userId.split(":")[1].replaceAll("}","").substring(1, userId.split(":")[1].replaceAll("}","").length()-1);
		if(! userId1.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Please provide valid user id.");
		}
		return adminService.deleteUsers(userId1);
	}
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value = "/searchAllArtifacts", method = RequestMethod.GET, produces = "application/json")
	public List<Artifact> searchAllArtifacts() {
		return adminService.searchAllArtifacts();
	}
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value = "/deleteArtifact", method = RequestMethod.POST, produces = "application/json")
	public String deleteArtifact(@RequestParam("artifactId") String artifactId) {
		if(! artifactId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Please provide valid artifact Id.");
		}
		
		return adminService.deleteArtifact(artifactId);
	}

}
