package com.tcs.digitalstore.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mongodb.gridfs.GridFSDBFile;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.ArtifactRepository;
import com.tcs.digitalstore.repository.ArtifactSearchRepository;
import com.tcs.digitalstore.repository.DocumentRepository;
import com.tcs.digitalstore.repository.UserRepository;
import com.tcs.digitalstore.service.ArtifactService;
import com.tcs.digitalstore.utility.DigitalStoreUtility;


@Controller
@RequestMapping(path="/document")
public class Documents {
	
	@Autowired ArtifactSearchRepository artifactSearchRepository;
	
	@Autowired ArtifactService artifactService;
	
	@Autowired DocumentRepository documentRepository;
	
	@Autowired UserRepository userRepository;
	
	@Autowired ArtifactRepository artifactRepository;
	
	@Value("${output.file.path}")
	private String outputFilePath;
	
	@Value("${userreport.path}")
	private String fileLocation;
	
	@Value("${appreport.path}")
	private String fileLocation1;
	
	@RequestMapping(value="/viewpdf",method=RequestMethod.GET,produces="application/pdf")
    public void  viewPdf(@RequestParam("fileId") String fileId,
    						HttpServletResponse response) throws IOException,Exception {
		
		if(fileId == null || fileId.isEmpty() || ! fileId.matches("[0-9A-Za-z]{1,64}")) {
			throw new InternalException("Valid file id is mandatory.");
		}
		
		GridFSDBFile gridfsFile = artifactService.retrieveById(fileId);
		
		/*	String fileName= (String) gridfsFile.getMetaData().get("name");
			if(! fileName.matches("^[a-zA-Z0-9!@#$%^&{}\\[\\]()_+\\-=,.~'` ]{1,255}$") || fileName.contains("\n")) {
				throw new InternalException("Illegal line break in file name.");
			} */
		response.setHeader("Content-disposition", "inline; filename=ds.pdf");
		IOUtils.copy(gridfsFile.getInputStream(), response.getOutputStream());
		response.flushBuffer();
    }
	
	@RequestMapping(value = "/downloadbyid/{fileId}", method = RequestMethod.GET,produces="application/x-msdownload")
    public void downloadFileById(@PathVariable("fileId") String fileId,HttpServletResponse response) throws IOException {
		if(fileId == null || fileId.isEmpty() || ! fileId.matches("[0-9A-Za-z]{1,64}")) {
			throw new InternalException("Valid file id is mandatory");
		}
		GridFSDBFile gridfsFile = artifactService.retrieveById(fileId);
    	
		String fileName= URLEncoder.encode((String) gridfsFile.getMetaData().get("name"),"UTF-8");
    	if(! fileName.matches("^[a-zA-Z0-9!@#$%^&{}\\[\\]()_+\\-=,.~'` ]{1,255}$") || fileName.contains("\n")) {
			throw new InternalException("Illegal line break in file name.");
		}
    	
    	// fileName = URLEncoder.encode( fileName,"UTF-8");
    	
    	// Get content type from file extension.
    	String contentType = DigitalStoreUtility.getContentType(fileName);
    	if(contentType.isEmpty()) {
    		throw new InternalException("Invalid Content Type to Download.");
    	}
    	
    	response.setContentType(contentType);    
        response.setHeader("Content-disposition", "attachment; filename="+ fileName);
        IOUtils.copy(gridfsFile.getInputStream(), response.getOutputStream());
        response.flushBuffer();
    }
	
	@RequestMapping(value = "/getfilebyid/{fileId}", method = RequestMethod.GET)
    public void getFilebyId(@PathVariable("fileID") String fileId,HttpServletResponse response) throws IOException {
		
		if(fileId == null || fileId.isEmpty() || ! fileId.matches("[0-9A-Za-z]{1,64}")) {
			throw new InternalException("Valid file id is mandatory.");
		}
		GridFSDBFile gridfsFile = documentRepository.getById(fileId);
		String fileName= URLEncoder.encode((String) gridfsFile.getMetaData().get("name"),"UTF-8");
		// Get content type from file extension.
    	String contentType = DigitalStoreUtility.getContentType(fileName);
    	if(contentType.isEmpty()) {
    		throw new InternalException("Invalid Content Type to Download.");
    	}
		IOUtils.copy(gridfsFile.getInputStream(), response.getOutputStream());
	    response.flushBuffer();
    }
	
	@RequestMapping(value = "/exportToExcelU", method = RequestMethod.GET,produces="application/x-msdownload")
	public void getUserReport(@RequestParam("fileId") String filename,HttpServletResponse response) throws IOException {
		try {	    
			    
			List<User> lstUser = userRepository.findAll();
		    HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("UserReport");
		    HSSFRow rowhead = sheet.createRow((short) 0);
		    
		    
		    HSSFCellStyle style = workbook.createCellStyle(); Font font = workbook.createFont();
	        font.setColor(HSSFColor.WHITE.index); font.setBoldweight(Font.BOLDWEIGHT_BOLD);
	        style.setFont(font);  style.setFillForegroundColor(HSSFColor.BROWN.index); style.setFillBackgroundColor(HSSFColor.ORANGE.index);
	        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  style.setFillPattern(HSSFCellStyle.BORDER_THICK);
	        style.setBorderBottom((short) 1); style.setBorderLeft((short) 1); style.setBorderRight((short) 1); style.setBorderTop((short) 1);
		    
	        Cell cell = rowhead.createCell(0);  cell.setCellValue("Employee ID"); cell.setCellStyle(style);
	        cell = rowhead.createCell(1);  cell.setCellValue("Full Name"); cell.setCellStyle(style);
	        cell = rowhead.createCell(2);  cell.setCellValue("Approval Status"); cell.setCellStyle(style);
	        cell = rowhead.createCell(3);  cell.setCellValue("Role"); cell.setCellStyle(style);
	        cell = rowhead.createCell(4);  cell.setCellValue("Business Unit"); cell.setCellStyle(style);      
	        cell = rowhead.createCell(5); cell.setCellValue("Approved By"); cell.setCellStyle(style);      
	        cell = rowhead.createCell(6); cell.setCellValue("Approval Date"); cell.setCellStyle(style);
		    
		    int i = 1;
		    for(User objUser : lstUser){
		    	 HSSFRow row = sheet.createRow(i);
		    	 
		    	 HSSFCellStyle style1 = workbook.createCellStyle(); Font font1 = workbook.createFont();
		    	 HSSFCellStyle style2 = workbook.createCellStyle();
			        font1.setColor(HSSFColor.BLACK.index);  style1.setFont(font1);
			        style1.setFillForegroundColor(HSSFColor.WHITE.index); style1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			        style1.setFillPattern(HSSFCellStyle.BORDER_THICK); style1.setFillBackgroundColor(HSSFColor.GREY_40_PERCENT.index);
			        style1.setBorderBottom((short) 1); style1.setBorderLeft((short) 1); style1.setBorderRight((short) 1); style1.setBorderTop((short) 1);
			        style2.setFillForegroundColor(HSSFColor.WHITE.index); style2.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			        style2.setFillPattern(HSSFCellStyle.BORDER_THICK); style2.setFillBackgroundColor(HSSFColor.GREY_40_PERCENT.index);
			        style2.setBorderBottom((short) 1); style2.setBorderLeft((short) 1); style2.setBorderRight((short) 1); style2.setBorderTop((short) 1);
			        
			        if(objUser.getApproverEmployeeName()==null) {
			        	objUser.setApproverEmployeeName("NA");
			        }
			        
			     Cell cell1 = row.createCell(0); cell1.setCellValue(objUser.getEmployeeId()); cell1.setCellStyle(style1);
			     cell1 = row.createCell(1);      cell1.setCellValue(objUser.getName());	     cell1.setCellStyle(style1);
			     cell1 = row.createCell(2);	     cell1.setCellValue(objUser.getApprovstatus()); cell1.setCellStyle(style1);
			     cell1 = row.createCell(3);      cell1.setCellValue(objUser.getRole()); cell1.setCellStyle(style1);
			     cell1 = row.createCell(4);	     cell1.setCellValue(objUser.getBusinessUnit()); cell1.setCellStyle(style1);
			     cell1 = row.createCell(5);	     cell1.setCellValue(objUser.getApproverEmployeeName()); cell1.setCellStyle(style1);
			     if(objUser.getApprovalDate() != null) {
			     java.util.Date date = objUser.getApprovalDate(); SimpleDateFormat df2 = new SimpleDateFormat("MM/dd/yyyy"); String dateText = df2.format(date);
			     cell1 = row.createCell(6);	     cell1.setCellValue(dateText); cell1.setCellStyle(style1);
			     } else {
			    	 cell1 = row.createCell(6); cell1.setCellValue("NA"); cell1.setCellStyle(style2);
			     }
		         i++;
		    }
		    
		   
		    FileOutputStream fileOut = new FileOutputStream(fileLocation);
		    workbook.write(fileOut);
		    fileOut.close();
		    workbook.close();
		    
		    File f=new File(fileLocation);
		    InputStream is = new FileInputStream(f);
		    String contentType = DigitalStoreUtility.getContentType(fileLocation);
		    response.setContentType(contentType);    
		    response.setHeader("Content-disposition","attachment; filename="+filename);
		    //System.out.println(fileId);
		    IOUtils.copy(is, response.getOutputStream());
		    response.flushBuffer();
		    
		    
		    } 
		    catch (FileNotFoundException e1) {
		        e1.printStackTrace();
		    } catch (IOException e1) {
		        e1.printStackTrace();
		    }
	}
	
	@RequestMapping(value = "/exportAppReportToExcel", method = RequestMethod.GET, produces = "application/x-msdownload")
	public void getAppReport(@RequestParam("fileId") String filename,HttpServletResponse response) throws IOException {
		try{
			
			List<Artifact> lstArtifact = artifactRepository.findAll();
			HSSFWorkbook workbook = new HSSFWorkbook();
		    HSSFSheet sheet = workbook.createSheet("ApplicationReport");
		    HSSFRow rowhead = sheet.createRow((short) 0);
		    
		    HSSFCellStyle style = workbook.createCellStyle(); Font font = workbook.createFont();
	        font.setColor(HSSFColor.WHITE.index); font.setBoldweight(Font.BOLDWEIGHT_BOLD);
	        style.setFont(font);  style.setFillForegroundColor(HSSFColor.BROWN.index); style.setFillBackgroundColor(HSSFColor.ORANGE.index);
	        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  style.setFillPattern(HSSFCellStyle.BORDER_THICK);
	        style.setBorderBottom((short) 1); style.setBorderLeft((short) 1); style.setBorderRight((short) 1); style.setBorderTop((short) 1);
	        
	        Cell cell = rowhead.createCell(0);  cell.setCellValue("App Name"); cell.setCellStyle(style);
	        cell = rowhead.createCell(1);  cell.setCellValue("Uploaded By"); cell.setCellStyle(style);
	        cell = rowhead.createCell(2);  cell.setCellValue("Reviewed By"); cell.setCellStyle(style);
	        cell = rowhead.createCell(3);  cell.setCellValue("Review Date"); cell.setCellStyle(style);
	        cell = rowhead.createCell(4);  cell.setCellValue("Review Status"); cell.setCellStyle(style);
	        
	        int i = 1;
		    for(Artifact objArtifact : lstArtifact){
		    	 HSSFRow row = sheet.createRow(i);
		    	 
		    	 HSSFCellStyle style1 = workbook.createCellStyle(); Font font1 = workbook.createFont();
		    	 HSSFCellStyle style2 = workbook.createCellStyle();
			        font1.setColor(HSSFColor.BLACK.index);  style1.setFont(font1);
			        style1.setFillForegroundColor(HSSFColor.WHITE.index); style1.setFillBackgroundColor(HSSFColor.GREY_40_PERCENT.index);
			        style1.setBorderBottom((short) 1); style1.setBorderLeft((short) 1); style1.setBorderRight((short) 1); style1.setBorderTop((short) 1);
			        style1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND); style1.setFillPattern(HSSFCellStyle.BORDER_THICK);
			        style2.setFillForegroundColor(HSSFColor.WHITE.index); style2.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			        style2.setFillPattern(HSSFCellStyle.BORDER_THICK); style2.setFillBackgroundColor(HSSFColor.GREY_40_PERCENT.index);
			        style2.setBorderBottom((short) 1); style2.setBorderLeft((short) 1); style2.setBorderRight((short) 1); style2.setBorderTop((short) 1);
			        if(objArtifact.getApproverName()==null){
			        	objArtifact.setApproverName("NA");
			        }
			        if(objArtifact.getApproverEmployeeId()==null){
			        	objArtifact.setApproverEmployeeId("NA");
			        }
			        
			     Cell cell1 = row.createCell(0); cell1.setCellValue(objArtifact.getName()); cell1.setCellStyle(style1);
			     cell1 = row.createCell(1);      cell1.setCellValue(objArtifact.getUploaderUserName()+" ("+objArtifact.getUploaderEmployeeId()+")");	cell1.setCellStyle(style1);
			     cell1 = row.createCell(2);	     cell1.setCellValue(objArtifact.getApproverName()+" ("+objArtifact.getApproverEmployeeId()+")"); cell1.setCellStyle(style1);
			     if(objArtifact.getApprovalDate() != null){
			    	 java.util.Date date = objArtifact.getApprovalDate(); SimpleDateFormat df2 = new SimpleDateFormat("MM/dd/yyyy");  String dateText = df2.format(date);
			     cell1 = row.createCell(3);      cell1.setCellValue(dateText); cell1.setCellStyle(style1);
			     } else {
			    	 cell1 = row.createCell(3); cell1.setCellValue("NA"); cell1.setCellStyle(style2);
			     }
			     cell1 = row.createCell(4);	     cell1.setCellValue(objArtifact.getApprovalStatus()); cell1.setCellStyle(style1);
		         i++;
		    }
		    
		    FileOutputStream fileOut = new FileOutputStream(fileLocation1);
		    workbook.write(fileOut);
		    fileOut.close();
		    workbook.close();
		    
		    File f=new File(fileLocation1);
		    InputStream is = new FileInputStream(f);
		    String contentType = DigitalStoreUtility.getContentType(fileLocation1);
		    response.setContentType(contentType);    
		    response.setHeader("Content-disposition","attachment; filename="+filename);
		    IOUtils.copy(is, response.getOutputStream());
		    response.flushBuffer();
			
		}
		catch(FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
