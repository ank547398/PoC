package com.tcs.digitalstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tcs.digitalstore.domain.GeMatixUserDetails;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.domain.validationchecks.UserRegistrationApprovalChecks;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.service.GeMatixAuthService;
import com.tcs.digitalstore.service.UserProvisionService;
import com.tcs.digitalstore.utility.DigitalStoreUtility;

@RestController
@RequestMapping(path="/user")
public class Users {
	@Autowired private UserProvisionService userProvisionService;
	@Autowired private GeMatixAuthService geMatixAuthService;
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public GeMatixUserDetails register(@Validated @RequestBody GeMatixAuthCommand geMatixAuthCommand){
        return geMatixAuthService.authenticate(geMatixAuthCommand.getEmployeeId(), geMatixAuthCommand.getUserPass());
    }
	
	@RequestMapping(value="/confirm", method=RequestMethod.POST)
	public String confirmRegistration(@Validated @RequestBody GeMatixUserDetails geMatixUserDetails){
		return userProvisionService.register(geMatixUserDetails);
    }
	
	@PreAuthorize("hasAnyAuthority('ADMIN')")
	@RequestMapping(value="/approve", method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public String approve(@Validated(value=UserRegistrationApprovalChecks.class) @RequestBody User userDet) {
		return userProvisionService.approve(userDet);
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/uploadprofilepic", method=RequestMethod.POST)
	public String uploadProfilePic(@RequestParam("userId")	String userId,@RequestParam("uploadedFiles") MultipartFile profilePic) {
		if(userId == null || userId.isEmpty()) {
			throw new InternalException("User id cannot be empty or null.");
		}
		if(! userId.matches("[0-9A-Za-z]{1,24}")) {
			throw new InternalException("Provide valid user id.");
		}
//		if(! profilePic.getOriginalFilename().matches("[a-zA-Z0-9]{1,200}\\.[a-zA-Z0-9]{1,10})")) {
//			throw new InternalException("Invalid file name/ type.");
//		}
		String fileExtension = DigitalStoreUtility.getFileExtension(profilePic.getOriginalFilename());
		if(fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("gif") || fileExtension.equalsIgnoreCase("jpg") 
			|| fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("bmp")) {
			return userProvisionService.uploadProfilePic(userId,profilePic);
		} 
		throw new InternalException("Invalid File Type to upload. Only images are allowed.");
	}
	
}
