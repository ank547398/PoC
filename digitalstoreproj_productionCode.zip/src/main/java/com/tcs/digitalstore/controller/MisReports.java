package com.tcs.digitalstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.repository.ArtifactStatRepository;
import com.tcs.digitalstore.repository.BusinessWiseStatRepository;
import com.tcs.digitalstore.repository.ContributorStatRepository;
import com.tcs.digitalstore.vo.BusinessStat;
import com.tcs.digitalstore.vo.ContributorStat;

@RestController
@RequestMapping(path="/reports")
public class MisReports {
	@Autowired private ContributorStatRepository contributorStatRepository;
	
	@Autowired private BusinessWiseStatRepository businessWiseStatRepository;
	
	@Autowired ArtifactStatRepository artifactStatRepository;
		
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/snaps/bybusiness", method=RequestMethod.GET,produces="application/json")
	public BusinessStat getBusinessStats(@RequestParam String businessName) {
		if(businessName == null || businessName.isEmpty() || ! businessName.matches("^[a-zA-Z]+[A-Za-z0-9 -]*$")) {
			throw new InternalException("Provide valid bisuness name which cannot be empty or null.");
		}
		
		BusinessStat businessSnapShot = businessWiseStatRepository.getSnap(businessName);
		if(businessSnapShot == null) {
			throw new InternalException("No business unit found.");
		}
		businessSnapShot.setContributedApplications(businessWiseStatRepository.getArtifacts(businessName));
		businessSnapShot.setContributors(businessWiseStatRepository.getContributors(businessName));
		return businessSnapShot;
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/snaps/byuploader", method=RequestMethod.GET,produces="application/json")
	public ContributorStat getUploaderSnap(@RequestParam String uploaderEmployeeId) {
		if(uploaderEmployeeId == null || uploaderEmployeeId.isEmpty()) {
			throw new InternalException("Employee id cannot be empty or null.");
		}
		if(! uploaderEmployeeId.matches("[\\d]{3,10}")) {
			throw new InternalException("Only digits are permissible in employee id.");
		}
		ContributorStat userProfile = contributorStatRepository.getStat(uploaderEmployeeId);
		
		userProfile.setArtifactsUploaded( contributorStatRepository.getArtifacts(uploaderEmployeeId));
		userProfile.setFeeds(contributorStatRepository.getFeeds(uploaderEmployeeId));
		return userProfile;
	}
	
	@PreAuthorize("hasAnyAuthority('GUEST','ADMIN','MANAGER')")
	@RequestMapping(value="/snaps/popularity", method=RequestMethod.GET,produces="application/json")
	public List<Artifact> computePopularity() {
		artifactStatRepository.computePopularity();
		return artifactStatRepository.getPopularArtifacts();
	}
}
