package com.tcs.digitalstore.vo;

import java.util.List;

public class BusinessStat {
	private String businessUnit;
	private int noOfAppsContributed;
	private int totalLikes;
	private int totalDownloads;
	private int totalViews;
	private float averageRating;
	
	private List<ArtifactSummary> artifacts;
	private List<ContributorSummary> contributors;
	
	public String getBusinessUnit() {
		return businessUnit.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getNoOfAppsContributed() {
		return noOfAppsContributed;
	}
	public void setNoOfAppsContributed(int noOfAppsContributed) {
		this.noOfAppsContributed = noOfAppsContributed;
	}
	public int getTotalLikes() {
		return totalLikes;
	}
	public void setTotalLikes(int totalLikes) {
		this.totalLikes = totalLikes;
	}
	public int getTotalDownloads() {
		return totalDownloads;
	}
	public void setTotalDownloads(int totalDownloads) {
		this.totalDownloads = totalDownloads;
	}
	public int getTotalViews() {
		return totalViews;
	}
	public void setTotalViews(int totalViews) {
		this.totalViews = totalViews;
	}
	public float getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(float averageRating) {
		this.averageRating = averageRating;
	}
	public List<ArtifactSummary> getContributedApplications() {
		return artifacts;
	}
	public void setContributedApplications(
			List<ArtifactSummary> artifacts) {
		this.artifacts = artifacts;
	}
	public List<ContributorSummary> getContributors() {
		return contributors;
	}
	public void setContributors(List<ContributorSummary> contributors) {
		this.contributors = contributors;
	}
}
