package com.tcs.digitalstore.vo;

import java.util.List;

public class ContributorStat {
	
	private String name;
	private String uploaderEmployeeId;
	private String emailId;
	private String businessUnit;
	private int noOfApps;
	private int totalLikes;
	private int totalDownloads;
	private int totalViews;
	private float averageRating;
	private List<ArtifactSummary> artifacts;
	private List<Feed> feeds;
	private String profilePicFileId;
	
	public String getProfilePicFileId() {
		return profilePicFileId;
	}
	public void setProfilePicFileId(String profilePicFileId) {
		this.profilePicFileId = profilePicFileId;
	}
	public List<Feed> getFeeds() {
		return feeds;
	}
	public void setFeeds(List<Feed> feeds) {
		this.feeds = feeds;
	}
	public List<ArtifactSummary> getArtifactsUploaded() {
		return artifacts;
	}
	public void setArtifactsUploaded(List<ArtifactSummary> artifacts) {
		this.artifacts = artifacts;
	}
	
	public String getName() {
		return name.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUploaderEmployeeId() {
		return uploaderEmployeeId.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public void setUploaderEmployeeId(String uploaderEmployeeId) {
		this.uploaderEmployeeId = uploaderEmployeeId;
	}
	public int getNoOfApps() {
		return noOfApps;
	}
	public void setNoOfApps(int noOfApps) {
		this.noOfApps = noOfApps;
	}
	public int getTotalLikes() {
		return totalLikes;
	}
	public void setTotalLikes(int totalLikes) {
		this.totalLikes = totalLikes;
	}
	public int getTotalDownloads() {
		return totalDownloads;
	}
	public void setTotalDownloads(int totalDownloads) {
		this.totalDownloads = totalDownloads;
	}
	public int getTotalViews() {
		return totalViews;
	}
	public void setTotalViews(int totalViews) {
		this.totalViews = totalViews;
	}
	public float getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(float averageRating) {
		this.averageRating = averageRating;
	}
	public String getEmailId() {
		return emailId.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
}
