package com.tcs.digitalstore.vo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ArtifactSummary {
	private String artifactId;
	private String name;
	private String logoURL;
	private int totalLikes;
	private int totalDownloads;
	private int totalViews;
	private float averageRating;
	private int ratingCount;
	
	


	public static String getOnlyStrings(String s) {
	    Pattern pattern = Pattern.compile("[^0-9 a-z A-Z]");
	    Matcher matcher = pattern.matcher(s);
	    String number = matcher.replaceAll("");
	    return number;
	 }
	
	
	public String getArtifactId() {
		return getOnlyStrings(artifactId).replaceAll("oid", "").trim();
		//return artifactId.replace("[ ", "").replace("$oid","").replace("]","").replace("\"", "").trim();
	}
	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
	public String getName() {
		//return name.replace("[", "").replace("]","").replace("\"", "").trim();
		return getOnlyStrings(name).trim();
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogoURL() {
		//return  logoURL.replace("[", "").replace("]","").replace("\"", "").trim();
		return getOnlyStrings(logoURL).trim();
	}
	public void setLogoURL(String logoURL) {
		this.logoURL = logoURL;
	}
	public int getTotalLikes() {
		return totalLikes;
	}
	public void setTotalLikes(int totalLikes) {
		this.totalLikes = totalLikes;
	}
	public int getTotalDownloads() {
		return totalDownloads;
	}
	public void setTotalDownloads(int totalDownloads) {
		this.totalDownloads = totalDownloads;
	}
	public int getTotalViews() {
		return totalViews;
	}
	public void setTotalViews(int totalViews) {
		this.totalViews = totalViews;
	}
	public float getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(float averageRating) {
		this.averageRating = averageRating;
	}
	public int getRatingCount() {
		return ratingCount;
	}


	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}
}
