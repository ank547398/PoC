package com.tcs.digitalstore.vo;


public class ContributorSummary {
	private String name;
	private String uploaderEmployeeId;
	private int noOfApps;
	private int totalLikes;
	private int totalDownloads;
	private int totalViews;
	private float averageRating;
	private String profilePicFileId;
	
	
	
	public String getProfilePicFileId() {
		return profilePicFileId;
	}
	public void setProfilePicFileId(String profilePicFileId) {
		this.profilePicFileId = profilePicFileId;
	}
	public String getUploaderEmployeeId() {
		return uploaderEmployeeId.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public void setUploaderEmployeeId(String uploaderEmployeeId) {
		this.uploaderEmployeeId = uploaderEmployeeId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setNoOfApps(int noOfApps) {
		this.noOfApps = noOfApps;
	}
	public void setTotalLikes(int totalLikes) {
		this.totalLikes = totalLikes;
	}
	public void setTotalDownloads(int totalDownloads) {
		this.totalDownloads = totalDownloads;
	}
	public void setTotalViews(int totalViews) {
		this.totalViews = totalViews;
	}
	public void setAverageRating(float averageRating) {
		this.averageRating = averageRating;
	}
	public String getName() {
		return name.replace("[", "").replace("]","").replace("\"", "").trim();
	}
	public int getNoOfApps() {
		return noOfApps;
	}
	public int getTotalLikes() {
		return totalLikes;
	}
	public int getTotalDownloads() {
		return totalDownloads;
	}
	public int getTotalViews() {
		return totalViews;
	}
	public float getAverageRating() {
		return averageRating;
	}
}
