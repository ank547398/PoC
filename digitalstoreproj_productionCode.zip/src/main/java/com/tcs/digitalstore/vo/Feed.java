package com.tcs.digitalstore.vo;

public class Feed {
	private String feedType;
	private String logoUrl;
	private String feedText1;
	private String feedText2;
	private String employeeId;
	private String employeeName;
	private String artifactName;
	private String userFeedType;
	public String getFeedType() {
		return feedType;
	}
	public void setFeedType(String feedType) {
		this.feedType = feedType;
	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public String getFeedText1() {
		return feedText1;
	}
	public void setFeedText1(String feedText1) {
		this.feedText1 = feedText1;
	}
	public String getFeedText2() {
		return feedText2;
	}
	public void setFeedText2(String feedText2) {
		this.feedText2 = feedText2;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getArtifactName() {
		return artifactName;
	}
	public void setArtifactName(String artifactName) {
		this.artifactName = artifactName;
	}
	public String getUserFeedType() {
		return userFeedType;
	}
	public void setUserFeedType(String userFeedType) {
		this.userFeedType = userFeedType;
	}
	
	
	
}
