package com.tcs.digitalstore.repository;

import java.util.List;

import com.tcs.digitalstore.domain.User;

public interface UserRepositoryCustom {
	List<User> findByEmployeeIds(List<String> employeeIds);
	User findNameByEmployeeId(String employeeId);
	User findById(String userId);
	void updateProfilePicId(String id,String profilePicId);
}
