package com.tcs.digitalstore.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.Artifact;

@Component
public class ArtifactSearchRepository {
	@Autowired
	MongoOperations mongoOperation;
	@Autowired
	MongoTemplate template;
	
	
	public Artifact findArtifactByFileId(String fileId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("artifactDocuments.id").is(fileId));
		Artifact artifact = template.findOne(query, Artifact.class);
		return artifact;
	}
	
}
