package com.tcs.digitalstore.repository;

public class AvgRating {
	private String artifactId;
	private int userCount;
	private float avgRating;
	public AvgRating() {
		
	}
	public AvgRating(String artifactId) {
		this.artifactId = artifactId;
	}
	
	public AvgRating(String artifactId,float avgRating,int userCount) {
		this.artifactId = artifactId;
		this.avgRating 	= avgRating;
		this.userCount 	= userCount;
	}
	
	public String getArtifactId() {
		return artifactId;
	}
	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
	
	public float getAvgRating() {
		return (Math.round(avgRating*100.0))/100;
	}
	public void setAvgRating(float avgRating) {
		this.avgRating = avgRating;
	}
	
	public int getUserCount() {
		return userCount;
	}
	public void setUserCount(int userCount) {
		this.userCount = userCount;
	}
}
