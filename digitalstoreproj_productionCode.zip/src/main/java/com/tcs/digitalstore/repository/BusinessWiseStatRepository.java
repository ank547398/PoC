package com.tcs.digitalstore.repository;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.vo.ArtifactSummary;
import com.tcs.digitalstore.vo.BusinessStat;
import com.tcs.digitalstore.vo.ContributorSummary;

@Component
public class BusinessWiseStatRepository {
	@Autowired
	private MongoTemplate mongoTemplate;
	@Autowired
	private MongoOperations mongoOperations;
	@Autowired
	private UserRepository userRepository;
	
	public BusinessStat getSnap(String businessName) {
		Aggregation aggregation = newAggregation(
				match(
						Criteria.where("business").is(businessName.trim()).
							andOperator(
						Criteria.where("approvalStatus").is("approved"))
				),
				group("business")
					.addToSet("business").as("businessUnit")
					.count().as("noOfAppsContributed")
					.avg("rating").as("averageRating")
					.sum("likes").as("totalLikes")
					.sum("views").as("totalViews")
					.sum("downloads").as("totalDownloads")
			);

		AggregationResults<BusinessStat> groupResults 
					= mongoTemplate.aggregate(
							aggregation, Artifact.class,BusinessStat.class);
		List<BusinessStat> list =  groupResults.getMappedResults();
		if(list == null || list.isEmpty()) {
			return null;
		}
		return list.get(0);
	}
	
	public List<ArtifactSummary> getArtifacts(String businessName) {
		Aggregation aggregation = newAggregation(
			    					match(
			    							Criteria.where("business").is(businessName.trim()).
			    								andOperator(
			    							Criteria.where("approvalStatus").is("approved"))
			    					),
			    					group("name")
			    						.addToSet("name").as("name")
			    						.addToSet("logoURL").as("logoURL")
			    						.addToSet("id").as("artifactId")
			    						.avg("rating").as("averageRating")
			    						.sum("likes").as("totalLikes")
			    						.sum("views").as("totalViews")
			    						.sum("downloads").as("totalDownloads")
			    						.addToSet("ratingCount").as("ratingCount")
			    				);
		
		AggregationResults<ArtifactSummary> groupResults 
								= mongoTemplate.aggregate(
										aggregation, Artifact.class,ArtifactSummary.class);
		List<ArtifactSummary> artifacts = groupResults.getMappedResults();
		if(artifacts == null) return new ArrayList<>();
		return artifacts;
	}
	
	public List<ContributorSummary> getContributors(String businessName) {
		Aggregation aggregation = newAggregation(
						match(
								Criteria.where("business").is(businessName.trim()).
									andOperator(
								Criteria.where("approvalStatus").is("approved"))
						),
						group("uploaderEmployeeId")
							.addToSet("uploaderEmployeeId").as("uploaderEmployeeId")
							.count().as("noOfApps")
							.avg("rating").as("averageRating")
							.sum("likes").as("totalLikes")
							.sum("views").as("totalViews")
							.sum("downloads").as("totalDownloads")
					);
		AggregationResults<ContributorSummary> groupResults 
					= mongoTemplate.aggregate(
							aggregation, Artifact.class,ContributorSummary.class);
		List<ContributorSummary> contributors = groupResults.getMappedResults();
		if(contributors == null) return new ArrayList<>();
		
		// Retrieve employee name for each of the contributor.
		for(ContributorSummary contributorSnapShot : contributors ) {
			String employeeId = contributorSnapShot.getUploaderEmployeeId().replaceAll("\\D", "");
			User user = userRepository.findNameByEmployeeId(employeeId);
			contributorSnapShot.setName(user.getName());
			contributorSnapShot.setProfilePicFileId(user.getProfilePicFileId());
			
		}
		return contributors;
	}
}
