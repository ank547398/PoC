package com.tcs.digitalstore.repository;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.limit;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.WriteResult;
import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.BusinessAppCountDto;
import com.tcs.digitalstore.domain.IndividualContributor;

public class ArtifactRepositoryImpl implements ArtifactRepositoryCustom {
	
	@Autowired private MongoTemplate mongoTemplate;
	@Autowired private MongoOperations mongoOperations;
	@Autowired ArtifactRepository artifactRepository;
	
	@Override
	public boolean updateLikesCount(String artifactId, int count) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(artifactId));
		Update update = new Update();
		update.set("likes", count);
		WriteResult wr =  mongoTemplate.updateFirst(query, update, Artifact.class);
		if(wr.getN() == 1) return true;
		return false;
	}
	
	@Override
	public boolean updateviewsCount(String artifactId, int count) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(artifactId));
		Update update = new Update();
		update.set("views", count);
		WriteResult wr =  mongoTemplate.updateFirst(query, update, Artifact.class);
		if(wr.getN() == 1) return true;
		return false;
	}
	
	@Override
	public boolean updatedownloadsCount(String artifactId, int count) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(artifactId));
		Update update = new Update();
		update.set("downloads", count);
		WriteResult wr =  mongoTemplate.updateFirst(query, update, Artifact.class);
		if(wr.getN() == 1) return true;
		return false;
	}
	
	@Override
	public boolean updateRating(String artifactId, float avgRating,int userCount) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(artifactId));
		Update update = new Update();
		update.set("rating", avgRating);
		update.set("ratingCount", userCount);
		WriteResult wr =  mongoTemplate.updateFirst(query, update, Artifact.class);
		if(wr.getN() == 1) return true;
		return false;
	}
	
	
	
	@Override
	public List<IndividualContributor> findTopContributingIndividuals()
	{
		Aggregation aggregation = newAggregation(
				match(Criteria.where("approvalStatus").is("approved")),
				group("uploaderEmployeeId").addToSet("uploaderEmployeeId").as("contributorEmployeeId").
			    	count().as("count").
			    	sum("likes").as("likes").
			    	sum("views").as("views").
			    	avg("rating").as("rating").
			    	sum("downloads").as("downloads"),
				    sort(Direction.DESC,"count"),
				    project("contributorEmployeeId","count","likes","views","rating","downloads"),
				    limit(5));
		
		/*Aggregation aggregation = newAggregation(
				group("uploaderEmployeeId").addToSet("uploaderEmployeeId").as("contributorEmployeeId").
			    	count().as("count").
			    	sum("likes").as("likes").
			    	sum("views").as("views").
			    	avg("rating").as("rating").
			    	sum("downloads").as("downloads"),
				    sort(Direction.DESC,"count"),
				    project("contributorEmployeeId","count","likes","views","downloads"),
				    limit(3)
			); */
	
			AggregationResults<IndividualContributor> groupResults = 
						mongoTemplate.aggregate(
								aggregation, 
								Artifact.class, 
								IndividualContributor.class);
			return groupResults.getMappedResults();
	}
	
	@Override
	public List<BusinessAppCountDto> findBusinesswiseAppcount()
	{
		Aggregation aggregation = newAggregation(
				match(Criteria.where("approvalStatus").is("approved")),
				    group("business").addToSet("business").as("business").
				    	count().as("count").
				    	sum("likes").as("likes").
				    	sum("views").as("views").
				    	avg("rating").as("rating").
				    	sum("downloads").as("downloads"),
				    sort(Direction.DESC,"count"),
				    project("business","count","likes","views","rating","downloads"),
				    limit(5)
				);
		
		AggregationResults<BusinessAppCountDto> groupResults = 
					mongoTemplate.aggregate(
							aggregation, 
							Artifact.class, 
							BusinessAppCountDto.class);
		return groupResults.getMappedResults();
	}
	
	@Override
	public List<Artifact> getPopularArtifacts() {
		Query query = new Query();
		query.limit(5);
		query.with(new Sort(Sort.Direction.DESC, "popularityPercent"));
		query.fields().include("id");
		query.fields().include("name");
		query.fields().include("likes");
		query.fields().include("views");
		query.fields().include("downloads");
		query.fields().include("rating");
		query.fields().include("popularityPercent");
		query.fields().include("logoURL");
		return mongoOperations.find(query, Artifact.class);
	}
	
	@Override
	public void computePopularity()
	{
		int maxLikes = 1, maxDownloads = 1, maxViews = 1;
		float ratingWeight = 0.4f,likeWeight=0.35f,downloadWeight=0.2f,viewWeight=0.05f;
		float maxRating = 5;
		List<Artifact> artifacts = artifactRepository.findByApprovalStatus("approved");
		try {
			for(Artifact artifact: artifacts) {
				if(artifact.getViews() > maxViews) 			{ maxViews = artifact.getViews(); }
				if(artifact.getLikes() > maxLikes) 			{ maxLikes = artifact.getLikes(); }
				if(artifact.getDownloads() > maxDownloads) 	{ maxDownloads = artifact.getDownloads(); }
			}
			for(Artifact artifact: artifacts) {
				if(maxLikes == 0 || maxDownloads == 0 ||maxViews == 0) {
					artifact.setPopularityPercent(0);
					updatePopularityPercent(artifact);
					return;
				}
				int popularityPercent =  Math.round( (((artifact.getLikes())/maxLikes) / likeWeight) +
									 (((artifact.getViews())/maxViews) / viewWeight) +
									 (((artifact.getDownloads())/maxDownloads) / downloadWeight) + 
									 (((artifact.getRating())/maxRating) / ratingWeight));
				
				artifact.setPopularityPercent(popularityPercent);
				updatePopularityPercent(artifact);
			}
		}catch(ArithmeticException  di) {
			
		}
	}
	
	@Override
	public void updatePopularityPercent(Artifact artifact) {
		System.out.println(artifact.getId());
		Query query = new Query(Criteria.where("_id").is(artifact.getId()));
		Update update = new Update().set("popularityPercent", artifact.getPopularityPercent());
		this.mongoTemplate.updateFirst(query, update, Artifact.class);
	}
	
	public Artifact findArtifactByFileId(String fileId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("artifactDocuments.id").is(fileId));
		Artifact artifact = mongoTemplate.findOne(query, Artifact.class);
		return artifact;
	}
	
	@Override
	public List<Artifact> findByAdminApprovalStatus(String approvalStatus,String userId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("approvalStatus").is(approvalStatus).andOperator(Criteria.where("approverId").is(userId)));
		List<Artifact> artifact = mongoTemplate.find(query, Artifact.class);
		return artifact;
	} 
	
}
