package com.tcs.digitalstore.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tcs.digitalstore.domain.SessionData;
import java.lang.String;
import java.util.List;

public interface SessionRepository extends MongoRepository<SessionData, String> {
	List<SessionData> findByUserName(String username);
	List<SessionData> findByTokenIssued(String tokenissued);
	
}
