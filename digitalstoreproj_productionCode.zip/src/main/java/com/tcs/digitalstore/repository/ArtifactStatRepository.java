package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.Artifact;

@Component
@PropertySource("classpath:application.properties")
public class ArtifactStatRepository {
	
	@Autowired private MongoTemplate mongoTemplate;
	
	@Autowired private MongoOperations mongoOperations;

	@Autowired ArtifactRepository artifactRepository;
	
	@Value("${max.artifacts.popular}")
	private int MAX_POPULAR_ARTIFACTS; 
	
	public List<Artifact> getPopularArtifacts() {
		computePopularity();
		Query query = new Query();
		//query.limit(MAX_POPULAR_ARTIFACTS);
		query.with(new Sort(Sort.Direction.DESC, "popularityPercent"));
//		query.fields().include("id");
//		query.fields().include("name");
//		query.fields().include("likes");
//		query.fields().include("views");
//		query.fields().include("downloads");
//		query.fields().include("rating");
//		query.fields().include("ratingCount");
//		query.fields().include("popularityPercent");
//		query.fields().include("logoURL");
		query.addCriteria(Criteria.where("approvalStatus").is("approved"));     //where condition is added to return only approved apps in popularApps view
		return mongoOperations.find(query, Artifact.class);
	}
	
	public void computePopularity()
	{
		int maxLikes = 1, maxDownloads = 1, maxViews = 1;  // values initialized to 1 to avoid divide by zero exception
		float ratingWeight = 0.4f,likeWeight=0.35f,downloadWeight=0.2f,viewWeight=0.05f;
		float maxRating = 5;
		List<Artifact> artifacts = artifactRepository.findByApprovalStatus("approved");
		
		for(Artifact artifact: artifacts) {
			if(artifact.getViews() > maxViews) 			{ maxViews = artifact.getViews(); }
			if(artifact.getLikes() > maxLikes) 			{ maxLikes = artifact.getLikes(); }
			if(artifact.getDownloads() > maxDownloads) 	{ maxDownloads = artifact.getDownloads(); }
		}
		
		for(Artifact artifact: artifacts) {
			int popularityPercent =  Math.round( 
									(
									(((float)(artifact.getLikes())/maxLikes) * likeWeight) +
									(((float)(artifact.getViews())/maxViews) * viewWeight) +
									(((float)(artifact.getDownloads())/maxDownloads) * downloadWeight) + 
									(((float)(artifact.getRating())/maxRating) * ratingWeight)
									) * 100
								);
			artifact.setPopularityPercent(popularityPercent);
			updatePopularityPercent(artifact);
			
		}
	}
	
	public void updatePopularityPercent(Artifact artifact) {
		Query query = new Query(Criteria.where("_id").is(artifact.getId()));
		Update update = new Update().set("popularityPercent", artifact.getPopularityPercent());
		this.mongoTemplate.updateFirst(query, update, Artifact.class);
	}
}
