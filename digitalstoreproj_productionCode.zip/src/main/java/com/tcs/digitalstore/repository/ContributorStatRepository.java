package com.tcs.digitalstore.repository;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.User;
import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.exceptions.InternalException;
import com.tcs.digitalstore.vo.ArtifactSummary;
import com.tcs.digitalstore.vo.Feed;
import com.tcs.digitalstore.vo.ContributorStat;

@Component
public class ContributorStatRepository {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private MongoOperations mongoOperations;
	
	@Autowired
	private UserRepository userRepository;
	
	public List<ArtifactSummary> getArtifacts(String contributorEmployeeId) {
		Aggregation aggregation = newAggregation(
				match(
						Criteria.where("uploaderEmployeeId").is(contributorEmployeeId.trim()).
								andOperator(
						Criteria.where("approvalStatus").is("approved"))
				),
				group("name")
					.addToSet("name").as("name")
					.addToSet("id").as("artifactId")
					.addToSet("logoURL").as("logoURL")
					.avg("rating").as("averageRating")
					.sum("likes").as("totalLikes")
					.sum("views").as("totalViews")
					.sum("downloads").as("totalDownloads")
					.addToSet("ratingCount").as("ratingCount"),
				sort(Direction.DESC,"name")
			);

		AggregationResults<ArtifactSummary> groupResults 
					= mongoTemplate.aggregate(
							aggregation, Artifact.class,ArtifactSummary.class);
		List<ArtifactSummary> artifacts = groupResults.getMappedResults();
		if(artifacts == null) return new ArrayList<>();
		return artifacts;
	}
	
	public List<Feed> getFeeds(String contributorEmployeeId) {
		
		
		Query query = new Query();
		query.addCriteria(Criteria.where("employeeId").is(contributorEmployeeId.trim()));
		query.with(new Sort(Direction.DESC,"feedDate"));
		
		List<UserFeed> userFeeds = mongoOperations.find(query, UserFeed.class);
		
		if(userFeeds == null) 
			return new ArrayList<Feed>();
		List<Feed> feeds = new ArrayList<>();
		for(UserFeed userFeed : userFeeds) {
			String userFeedType = userFeed.getUserFeedType().name().trim();
			Feed feed = new Feed();
			feed.setFeedType(userFeedType);
			switch(userFeedType) {
				case "LIKED":
					feed.setFeedText1(userFeed.getEmployeeName() + " liked ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
				case "VIEWED":
					feed.setFeedText1(userFeed.getEmployeeName() + " viewed ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
				case "DOWNLOADED":
					feed.setFeedText1(userFeed.getEmployeeName() + " downloaded ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
				case "RATING":
					feed.setFeedText1(userFeed.getEmployeeName() + " rated ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
				case "UPLOADED":
					feed.setFeedText1(userFeed.getEmployeeName() + " uploaded ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
				case "UPDATED":
					feed.setFeedText1(userFeed.getEmployeeName() + " updated ");
					feed.setFeedText2(userFeed.getArtifactName());
					break;
			}
			feeds.add(feed);
		}
		return feeds;
	}
	
	public ContributorStat getStat(String contributorEmployeeId) {
		User user = userRepository.findNameByEmployeeId(contributorEmployeeId);
		if(user == null) {
			throw new InternalException("User not found.");
		}
		
		
		
		Aggregation aggregation = newAggregation(
				match(Criteria.where("uploaderEmployeeId").is(contributorEmployeeId.trim()).
							andOperator(Criteria.where("approvalStatus").is("approved"))
				),
				group("uploaderEmployeeId")
					.addToSet("uploaderEmployeeId").as("uploaderEmployeeId")
					.count().as("noOfApps")
					.avg("rating").as("averageRating")
					.sum("likes").as("totalLikes")
					.sum("views").as("totalViews")
					.sum("downloads").as("totalDownloads")
			);
		AggregationResults<ContributorStat> groupResults 
					= mongoTemplate.aggregate(
							aggregation, Artifact.class,ContributorStat.class);
		
		List<ContributorStat> contributors = groupResults.getMappedResults();
		if(contributors == null || contributors.size() == 0) {
			ContributorStat userProfile  = new ContributorStat();
			userProfile.setName(user.getName());
			userProfile.setUploaderEmployeeId(user.getEmployeeId());
			userProfile.setEmailId(user.getMailId());
			userProfile.setBusinessUnit(user.getBusinessUnit());
			userProfile.setProfilePicFileId(user.getProfilePicFileId());
			return userProfile;
		}
			
		ContributorStat userProfile  = contributors.get(0);
		userProfile.setName(user.getName());
		userProfile.setUploaderEmployeeId(user.getEmployeeId());
		userProfile.setEmailId(user.getMailId());
		userProfile.setBusinessUnit(user.getBusinessUnit());
		userProfile.setProfilePicFileId(user.getProfilePicFileId()); 
		return userProfile;
	}
}
