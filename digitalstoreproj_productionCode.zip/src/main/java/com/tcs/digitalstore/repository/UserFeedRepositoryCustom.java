package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.domain.UserFeedToDisplay;

@RepositoryRestResource(collectionResourceRel = "userFeed", path = "userfeed")
public interface UserFeedRepositoryCustom {
	
	UserFeed findLikedByUserIdArtifactId(String userId,String artifactId);
	
	UserFeed findViewedByUserIdArtifactId(String userId,String artifactId);
	
	UserFeed findDownloadedByUserIdArtifactId(String userId,String artifactId);
	
	UserFeed findRatingByUserIdArtifactId(String userId,String artifactId);
	
	List<UserFeed> findAllByUserIdArtifactId(String userId,String artifactId);
	
	AvgRating getAverageRating(String artifactId);
	
	List<UserFeedToDisplay> getFeeds();
	
	boolean updateArtifactId(String oldArtifactId,String newArtifactId);
}
