package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.tcs.digitalstore.domain.Artifact;
import java.lang.String;


@RepositoryRestResource(collectionResourceRel = "artifact", path = "artifact")
public interface ArtifactRepository extends MongoRepository<Artifact, String> , ArtifactRepositoryCustom {
	List<Artifact> findById(@Param("id") String id);
	
	Artifact findOne(@Param("id") String id);
	
	List<Artifact> findByname(@Param("name") String name);
	
	List<Artifact> findBynameLike(@Param("name") String name);
	
	List<Artifact> findByBusinessLike(@Param("business")String business);
	
	List<Artifact> findByUploaderUserName(@Param("user")String uploadedBy);
	
	List<Artifact> findByApprovalStatus(@Param("approvalStatus")String approvalStatus);
	
	List<Artifact> findByUploaderEmployeeId(@Param("employeeId")String employeeId);
}
