package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.tcs.digitalstore.domain.User;

@Component
public class UserRepositoryImpl implements UserRepositoryCustom {
	
	@Autowired private MongoTemplate mongoTemplate;
	
	@Override
	public List<User> findByEmployeeIds(List<String> employeeIds) {
		Query query = new Query();
		query.addCriteria(
					Criteria.where("uploaderEmployeeId").in(employeeIds)
					);
		return mongoTemplate.find(query, User.class);
	}
	
	@Override
	public User findNameByEmployeeId(String employeeId) {
		Query query = new Query();
		query.addCriteria(
					Criteria.where("employeeId").is(employeeId)
					);
		return mongoTemplate.findOne(query, User.class);
	}
		
	@Override
	public User findById(String userId) {
		Query query = new Query();
		query.addCriteria(
					Criteria.where("id").is(userId)
					);
		return mongoTemplate.findOne(query, User.class);
	}
	
	@Override
	public void updateProfilePicId(String userId,String profilePicId) {
		Query query = new Query(Criteria.where("id").is(userId));
		Update update = new Update().set("profilePicFileId", profilePicId);
		this.mongoTemplate.updateFirst(query, update, User.class);
	}
}
