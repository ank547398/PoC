package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.tcs.digitalstore.domain.UserFeed;

@RepositoryRestResource(collectionResourceRel = "userFeed", path = "userfeed")
public interface UserFeedRepository extends MongoRepository<UserFeed, String>,UserFeedRepositoryCustom {
	
	List<UserFeed> findById(@Param("id") String id);
	
	List<UserFeed> findByArtifactId(@Param("artifactId") String artifactId);
	
	List<UserFeed> findByUserId(@Param("userId") String userId);
	
	List<UserFeed> findByEmployeeId(@Param("employeeId") String employeeId);
	
	
}
