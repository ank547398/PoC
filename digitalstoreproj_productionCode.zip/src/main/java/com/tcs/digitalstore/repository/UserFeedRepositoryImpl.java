package com.tcs.digitalstore.repository;


import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongodb.WriteResult;
import com.tcs.digitalstore.domain.UserFeed;
import com.tcs.digitalstore.domain.UserFeedToDisplay;


@Component
public class UserFeedRepositoryImpl implements UserFeedRepositoryCustom {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private MongoOperations mongoOperations;
	
	@Autowired
	UserFeedRepository userFeedRepository;
	
	@Override
	public UserFeed findLikedByUserIdArtifactId(String userId, String artifactId) {
		Query query = new Query();
		query.addCriteria(
						Criteria.where("userId").is(userId).andOperator(
						Criteria.where("artifactId").is(artifactId).andOperator(
						Criteria.where("userFeedType").is("LIKED"))));
		return mongoTemplate.findOne(query, UserFeed.class);
	}

	@Override
	public UserFeed findViewedByUserIdArtifactId(String userId,
			String artifactId) {
		Query query = new Query();
		query.addCriteria(
						Criteria.where("userId").is(userId).andOperator(
						Criteria.where("artifactId").is(artifactId).andOperator(
						Criteria.where("userFeedType").is("VIEWED"))));
		return mongoTemplate.findOne(query, UserFeed.class);
	}

	@Override
	public UserFeed findDownloadedByUserIdArtifactId(String userId,
			String artifactId) {
		Query query = new Query();
		query.addCriteria(
						Criteria.where("userId").is(userId).andOperator(
						Criteria.where("artifactId").is(artifactId).andOperator(
						Criteria.where("userFeedType").is("DOWNLOADED"))));
		return mongoTemplate.findOne(query, UserFeed.class);
	}

	@Override
	public UserFeed findRatingByUserIdArtifactId(String userId,
			String artifactId) {
		Query query = new Query();
		query.addCriteria(
						Criteria.where("userId").is(userId).andOperator(
						Criteria.where("artifactId").is(artifactId).andOperator(
						Criteria.where("userFeedType").is("RATING"))));
		return mongoTemplate.findOne(query, UserFeed.class);
	}
	
	@Override
	public List<UserFeed> findAllByUserIdArtifactId(String userId,String artifactId) {
		Query query = new Query();
		query.addCriteria(
						Criteria.where("userId").is(userId).andOperator(
						Criteria.where("artifactId").is(artifactId)));
		return mongoTemplate.find(query, UserFeed.class);
	}
	
	@Override
	public AvgRating getAverageRating(String artifactId) {
		Aggregation aggregation = newAggregation(
			    match(Criteria.where("userFeedType").is("RATING").andOperator(
			    		Criteria.where("artifactId").is(artifactId))),
			    group("artifactId")
			    	.avg("rating").as("avgRating")
			    	.count().as("userCount"));
		
		AggregationResults<AvgRating> groupResults = mongoTemplate.aggregate(
			    aggregation, UserFeed.class, AvgRating.class);
		List<AvgRating> list = groupResults.getMappedResults();
		if(list == null || list.size() ==0) return new AvgRating(artifactId);
		return list.get(0);
	}
	
	public List<UserFeedToDisplay> getFeeds() {
		Query query = new Query();
		query.with(new Sort(Direction.DESC,"feedDate"));
		List<UserFeed> userFeeds = mongoOperations.find(query, UserFeed.class);
		
		if(userFeeds == null) 
			return new ArrayList<UserFeedToDisplay>();
		List<UserFeedToDisplay> feeds = new ArrayList<>();
		for(UserFeed userFeed : userFeeds) {
			UserFeedToDisplay userFeedToDisplay = new UserFeedToDisplay();
			String userFeedType = userFeed.getUserFeedType().name().trim();
			
			userFeedToDisplay.setUserId(userFeed.getUserId());
			userFeedToDisplay.setEmployeeId(userFeed.getEmployeeId());
			userFeedToDisplay.setUserName(userFeed.getEmployeeName());
			userFeedToDisplay.setArtifactId(userFeed.getArtifactId());
			userFeedToDisplay.setFeedType(userFeedType);
			switch(userFeedType) {
				case "LIKED":
					userFeedToDisplay.setFeedText1(" liked ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
				case "VIEWED":
					userFeedToDisplay.setFeedText1(" viewed ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
				case "DOWNLOADED":
					userFeedToDisplay.setFeedText1(" downloaded ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
				case "RATING":
					userFeedToDisplay.setFeedText1(" rated ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
				case "UPLOADED":
					userFeedToDisplay.setFeedText1(" uploaded ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
				case "UPDATED":
					userFeedToDisplay.setFeedText1(" updated ");
					userFeedToDisplay.setFeedText2(userFeed.getArtifactName());
					break;
			}
			feeds.add(userFeedToDisplay);
		}
		return feeds;
	}
	
	@Override
	public boolean updateArtifactId(String oldArtifactId,String newArtifactId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("artifactId").is(oldArtifactId));
		Update update = new Update();
		update.set("artifactId", newArtifactId);
		WriteResult wr =  mongoTemplate.updateMulti(query, update, UserFeed.class);
		if(wr.getN() >= 1) return true;
		return false;
	}
}
