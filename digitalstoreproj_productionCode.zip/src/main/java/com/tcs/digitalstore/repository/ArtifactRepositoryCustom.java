package com.tcs.digitalstore.repository;

import java.util.List;

import com.tcs.digitalstore.domain.Artifact;
import com.tcs.digitalstore.domain.BusinessAppCountDto;
import com.tcs.digitalstore.domain.IndividualContributor;

public interface ArtifactRepositoryCustom {
	boolean updateLikesCount(String artifactId,int count);
	boolean updateviewsCount(String artifactId,int count);
	boolean updatedownloadsCount(String artifactId,int count);
	boolean updateRating(String artifactId, float count,int ratingCount);
	List<BusinessAppCountDto> findBusinesswiseAppcount();
	List<IndividualContributor> findTopContributingIndividuals();
	List<Artifact> getPopularArtifacts();
	void computePopularity();
	void updatePopularityPercent(Artifact artifact);
	Artifact findArtifactByFileId(String fileId);
	public List<Artifact> findByAdminApprovalStatus(String approvalStatus,String userId);
}
