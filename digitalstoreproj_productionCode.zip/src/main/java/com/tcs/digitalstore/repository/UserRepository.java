package com.tcs.digitalstore.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import com.tcs.digitalstore.domain.User;


public interface UserRepository extends MongoRepository<User, String>,UserRepositoryCustom {

	public List<User> findByEmployeeId(@Param("employeeId") String employeeId);
	
	public List<User> findByMailId(@Param("mailId") String mailId);
	
	public List<User> findByApprovstatus(@Param("approvstatus") String approvstatus);
	
	public List<User> findAll();
	
	public User findOne(@Param("id") String id);
	
}
