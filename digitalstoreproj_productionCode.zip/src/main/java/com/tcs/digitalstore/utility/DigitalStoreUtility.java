package com.tcs.digitalstore.utility;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringEscapeUtils;

public class DigitalStoreUtility {
	
	public static boolean isEmpty(String src) {
		return (src == null || src.trim().isEmpty() || src == "");
	}
	
	public static String sanitize(final String input) {
		if (input == null || input.isEmpty()) {
		       return "";
		}
		String output;
        output = StringEscapeUtils.escapeHtml(input);
        output = StringEscapeUtils.escapeJavaScript(input);
        output = StringEscapeUtils.escapeSql(input);
        return output;
	}
	
	public static String getContentType(String fileName) {
		String fileExtension = getFileExtension(fileName);
		
		// Images.
		if(fileExtension.equalsIgnoreCase("doc")) {
			return "application/msword";
		} else if(fileExtension.equalsIgnoreCase("xls")) {
			return "application/vnd.ms-excel";
		} else if(fileExtension.equalsIgnoreCase("ppt")) {
			return "application/vnd.ms-powerpoint";
		} else if(fileExtension.equalsIgnoreCase("docx")) {
			return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		} else if(fileExtension.equalsIgnoreCase("xlsx")) {
			return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		} else if(fileExtension.equalsIgnoreCase("pptx")) {
			return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
		} 
		
		// Open office.
		else if(fileExtension.equalsIgnoreCase("odt")) {
			return "application/vnd.oasis.opendocument.text";
		} else if(fileExtension.equalsIgnoreCase("ods")) {
			return "application/vnd.oasis.opendocument.spreadsheet";
		} else if(fileExtension.equalsIgnoreCase("odp")) {
			return "application/vnd.oasis.opendocument.presentation";
		} 
		
		// PDF.
		else if(fileExtension.equalsIgnoreCase("pdf")) {
			return "application/pdf";
		} 
		
		// Images
		else if(fileExtension.equalsIgnoreCase("png")) {
			return "image/png";
		}else if(fileExtension.equalsIgnoreCase("jpg")) {
			return "image/jpeg";
		}else if(fileExtension.equalsIgnoreCase("jpeg")) {
			return "image/jpeg";
		}else if(fileExtension.equalsIgnoreCase("bmp")) {
			return "image/bmp";
		}else if(fileExtension.equalsIgnoreCase("gif")) {
			return "image/gif";
		}
		
		return "";
	}
	
	public static String getFileExtension(String fileName) {
		int i = fileName.lastIndexOf('.');
		if (i > 0) {
		    return fileName.substring(i+1);
		}
		return "";
	}

	public static boolean setProperties(Object artiIn,Object artiOut) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, IntrospectionException{		
		for (PropertyDescriptor pd : Introspector.getBeanInfo(artiIn.getClass()).getPropertyDescriptors()) {
			if (pd.getReadMethod() != null && !"class".equals(pd.getName()))
				if(pd.getReadMethod().invoke(artiIn)!=null){
					System.out.println(pd.getName()+" : "+pd.getReadMethod().invoke(artiIn));
					BeanUtils.setProperty(artiOut,pd.getName(),pd.getReadMethod().invoke(artiIn));
				}
		}		
		return true;
	}


}
