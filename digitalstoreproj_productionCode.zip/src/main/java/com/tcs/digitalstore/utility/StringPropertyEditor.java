package com.tcs.digitalstore.utility;

import java.beans.PropertyEditorSupport;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.web.util.HtmlUtils;

public class StringPropertyEditor extends PropertyEditorSupport {
	private boolean escapeHTML;
    private boolean escapeJavaScript;
    private boolean escapeSQL;

    public StringPropertyEditor() {
        super();
    }

    public StringPropertyEditor(boolean escapeHTML, boolean escapeJavaScript,
            boolean escapeSQL) {
        super();
        this.escapeHTML = escapeHTML;
        this.escapeJavaScript = escapeJavaScript;
        this.escapeSQL = escapeSQL;
    }

    public void setAsText(String text) {
        if (text == null) {
            setValue(null);
        } else {
            String value = text;
            if (escapeHTML) {
              // value = StringEscapeUtils.escapeHtml(value);
            	value = HtmlUtils.htmlEscape(text);
            }
            setValue(value);
        }
    }

    public String getAsText() {
        Object value = getValue();
        return (value != null ? value.toString() : "");
    }
}
