package com.tcs.digitalstore.utility.mailer;

import java.io.File;
import java.io.StringWriter;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.tcs.digitalstore.exceptions.InternalException;

import freemarker.cache.FileTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.Version;

@Service
public class TemplateParser {
	public String parse(String templateName,Map<String, Object> data) {
		try {
			// 	Configure Free-marker
			Configuration cfg = new Configuration(new Version("2.3.22"));
			cfg.setTemplateLoader(new FileTemplateLoader(new File("src/main/resources/templates/mailalerts")));
			Template template = cfg.getTemplate(templateName);
			StringWriter writer = new StringWriter();
			template.process(data, writer);
			return writer.getBuffer().toString();
		}catch(Exception ex) {
			throw new InternalException("Failed to parse template: " + templateName,ex);
		}
	}
}
