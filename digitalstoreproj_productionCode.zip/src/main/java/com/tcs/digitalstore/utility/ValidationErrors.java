package com.tcs.digitalstore.utility;

import java.util.ArrayList;
import java.util.List;

public class ValidationErrors {
	private final List<FieldErrorDTO> list;
	
	public ValidationErrors() {
		this.list = new ArrayList<>();
	}
	
	public void add(String fieldName,String fieldErrorMessage) {
		this.list.add(new FieldErrorDTO(fieldName,fieldErrorMessage));
	}
	
	public List<FieldErrorDTO> getList() {
		return this.list;
	}
}
