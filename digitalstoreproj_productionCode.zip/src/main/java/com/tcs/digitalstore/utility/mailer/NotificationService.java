package com.tcs.digitalstore.utility.mailer;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class NotificationService {
	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);
	@Autowired private TemplateParser templateParser;
	private JavaMailSenderImpl javaMailSender;
	
	@Autowired
	public NotificationService(JavaMailSender javaMailSender){
		this.javaMailSender = (JavaMailSenderImpl) javaMailSender;
	}
	
	@Async
	public void send(PayLoad payload) {
		MimeMessage message;
		MimeMessageHelper helper;
		try {
			message = javaMailSender.createMimeMessage();
			helper = new MimeMessageHelper(message, true);
			helper.setFrom("tcs.digitalstore@tcs.com");
			helper.setCc("chaitanya.pathak@tcs.com");
			helper.setTo(new InternetAddress(payload.getToMailId()));

			String subject;
			if(payload.getNotificationType().equals(NotificationType.APP_APPROVED) || 
					payload.getNotificationType().equals(NotificationType.APP_REJECTED) || 
					payload.getNotificationType().equals(NotificationType.APP_UPLOADED)) {
				subject = String.format(payload.getNotificationType().getSubjectLine(), (String) payload.getValues().get("appName"));
			} else {
				subject = payload.getNotificationType().getSubjectLine();
			}
			helper.setSubject(subject);
			String mailHtml = templateParser.parse(payload.getNotificationType().getTemplateName(),payload.getValues());
			helper.setText(mailHtml,true);
			javaMailSender.send(message);
		} catch(Exception ex) {
			logger.error("Error in sending mail.");
		}
	}
}
