package com.tcs.digitalstore.utility;

public class FieldErrorDTO {
	private final String name;
	private final String message;
	
	public FieldErrorDTO(String name,String message) {
		this.name = name;
		this.message = message;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getMessage() {
		return this.message;
	}
}
