package com.tcs.digitalstore.utility;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AccountStatusException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tcs.digitalstore.exceptions.InternalException;

@ControllerAdvice
public class RestErrorHandler {
	private static final Logger logger = LoggerFactory.getLogger(RestErrorHandler.class);
	
	
	@InitBinder
	public void dataBinding(WebDataBinder binder) {
		binder.registerCustomEditor(String.class, new StringPropertyEditor(true,true,true));;
	}
	
	@ExceptionHandler(UsernameNotFoundException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<ErrorMessage> authenticationException(HttpServletRequest req,UsernameNotFoundException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.UNAUTHORIZED);
    }
		
	@ExceptionHandler(AccountStatusException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<ErrorMessage> authenticationException(HttpServletRequest req,AccountStatusException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.UNAUTHORIZED);
    }
	
	@ExceptionHandler(AuthenticationCredentialsNotFoundException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<ErrorMessage> authenticationException(HttpServletRequest req,AuthenticationCredentialsNotFoundException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.UNAUTHORIZED);
    }
	
	@ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<ErrorMessage> authenticationException(HttpServletRequest req,BadCredentialsException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.UNAUTHORIZED);
    }
	
	@ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<ErrorMessage> authenticationException(HttpServletRequest req,AuthenticationException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.UNAUTHORIZED);
    }
	
	@ExceptionHandler(value=InternalException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ErrorMessage> internalException(HttpServletRequest req,InternalException ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(),req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(value=Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ErrorMessage> unExpectedException(HttpServletRequest req,Exception ex) {
		ErrorMessage errorMessage = new ErrorMessage("Unexpected Error.",req.getRequestURI());
		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	    
	@ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ValidationErrors processValidationError(MethodArgumentNotValidException ex) {
    	BindingResult result = ex.getBindingResult();
        List<FieldError> fieldErrors = result.getFieldErrors();
        return processFieldErrors(fieldErrors);
    }
	
	private ValidationErrors processFieldErrors(List<FieldError> fieldErrors) {
    	ValidationErrors validationErrors = new ValidationErrors();
        for (FieldError fieldError: fieldErrors) {
        	// String localizedErrorMessage = resolveLocalizedErrorMessage(fieldError);
        	validationErrors.add(fieldError.getField(),fieldError.getDefaultMessage());
        	System.out.println(fieldError.getDefaultMessage());
        }
        return validationErrors;
    }
    
    /**
    private String resolveLocalizedErrorMessage(FieldError fieldError) {
        Locale currentLocale =  LocaleContextHolder.getLocale();
        String localizedErrorMessage = messageSource.getMessage(fieldError, currentLocale);
 
        //If the message was not found, return the most accurate field error code instead.
        //You can remove this check if you prefer to get the default error message.
        if (localizedErrorMessage.equals(fieldError.getDefaultMessage())) {
            String[] fieldErrorCodes = fieldError.getCodes();
            localizedErrorMessage = fieldErrorCodes[0];
        }
        return localizedErrorMessage;
    }**/
}
