package com.tcs.digitalstore.utility.mailer;

import java.util.Map;

public class PayLoad {
	
	private final String toMailId;
	private final NotificationType notificationType;
	private final Map<String,Object> values;
	
	public PayLoad(String toMailId, NotificationType notificationType,
			Map<String, Object> values) {
		super();
		this.toMailId = toMailId;
		this.notificationType = notificationType;
		this.values = values;
	}
	
	public String getToMailId() {
		return toMailId;
	}
	public NotificationType getNotificationType() {
		return notificationType;
	}
	public Map<String, Object> getValues() {
		return values;
	}
	
	@Override
	public String toString() { 
		return toMailId +", " + notificationType.getTemplateName();
	}
}
