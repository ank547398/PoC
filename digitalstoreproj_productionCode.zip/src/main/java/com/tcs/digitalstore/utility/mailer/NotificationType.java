package com.tcs.digitalstore.utility.mailer;

public enum NotificationType {
	
	USER_REGISTRATION("User Registration","Digital Store Notification: Registration Request Received","RegistrationRequestReceived.ftl"),
	USER_REGISTRATION_APPROVAL("Registration Approval","Digital Store Notification: Registration Approval","RegistrationRequestApproved.ftl"),
	
	APP_UPLOADED("App Uploaded","Digital Store Notification: App %s Uploaded","AppUploaded.ftl"),
	APP_APPROVED("App Approved","Digital Store Notification: App %s Approved","AppApproved.ftl"),
	APP_REJECTED("App Rejected","Digital Store Notification: App %s Rejected","AppRejected.ftl");
	
	
	private final String value;
	private final String subjectLine;
	private final String templateName;
	
	private NotificationType(String value,String subjectLine,String templateName) {
		this.value = value;
		this.subjectLine = subjectLine;
		this.templateName = templateName;
	}

	public String getValue() {
		return value;
	}


	public String getSubjectLine() {
		return subjectLine;
	}
	
	public String getTemplateName() {
		return templateName;
	}
}
