package com.tcs.digitalstore.domain;

public enum UserFeedType {
	LIKED,RATING,VIEWED,DOWNLOADED,UPLOADED,UPDATED;
}
