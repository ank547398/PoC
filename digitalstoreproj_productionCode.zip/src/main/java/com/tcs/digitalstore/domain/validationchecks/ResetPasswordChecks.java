package com.tcs.digitalstore.domain.validationchecks;

public interface ResetPasswordChecks {

}
