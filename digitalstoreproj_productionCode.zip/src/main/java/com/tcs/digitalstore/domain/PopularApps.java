package com.tcs.digitalstore.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class PopularApps implements Comparable<PopularApps> {
	
	public static final double WEITAGERATING = 0.4;
	public static final double WEITAGELIKE = 0.35;
	public static final double WEITAGEDOWNLOAD = 0.2;
	public static final double WEITAGEVIEW = 0.05;
	
	public static final int LIMITRATING = 5;
	public static final int LIMITLIKE = 20;
	public static final int LIMITDOWNLOAD = 19;
	public static final int LIMITVIEW = 40;
	
	private String artifactId;
	private double rating;
	private int likes;
	private int downloads;
	private int views;
	
	private double finalScore;
	
	public static String getOnlyStrings(String s) {
	    Pattern pattern = Pattern.compile("[^0-9 a-z A-Z]");
	    Matcher matcher = pattern.matcher(s);
	    String number = matcher.replaceAll("");
	    return number;
	 }
	
	public String getArtifactId() {
		return getOnlyStrings(artifactId).replaceAll("oid", "").trim();
	}
	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
	
	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public int getDownloads() {
		return downloads;
	}

	public void setDownloads(int downloads) {
		this.downloads = downloads;
	}

	public int getViews() {
		return views;
	}

	public void setViews(int views) {
		this.views = views;
	}

	public double getFinalScore() {
		return finalScore;
	}

	public void setFinalScore(double finalScore) {
		this.finalScore = finalScore;
	}
	
	public int compareTo(PopularApps obj1)
	{
		if ( this.getFinalScore() < obj1.getFinalScore() )
            return 1;
        else
            return -1;
	}
	

}
