package com.tcs.digitalstore.domain;
import org.springframework.web.multipart.MultipartFile;


public class DocumentUploaded {
	private String fileId;
	private String fileName;
	private String displayName;
	private String documentType;
	private String contentType;
	private String uploaderUserName;
	private String fileExtension;
	private boolean isPdf;
	private String pdfFileId;
	
	public boolean isPdf() {
		return isPdf;
	}
	

	public String getFileExtension() {
		return fileExtension;
	}


	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}


	public void setPdf(boolean isPdf) {
		this.isPdf = isPdf;
	}


	public String getPdfFileId() {
		return pdfFileId;
	}


	public void setPdfFileId(String pdfFileId) {
		this.pdfFileId = pdfFileId;
	}

	private MultipartFile document; 

	public ArtifactDocument getArtifactDocument() {
		return new ArtifactDocument(this.fileId,this.fileName, this.displayName,this.documentType,
				this.uploaderUserName,this.contentType,this.isPdf,this.pdfFileId);
	}
	
	
	public String getFileId() {
		return fileId;
	}
	
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public MultipartFile getDocument() {
		return document;
	}

	public void setDocument(MultipartFile document) {
		this.document = document;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getUploaderUserName() {
		return uploaderUserName;
	}

	public void setUploaderUserName(String uploaderUserName) {
		this.uploaderUserName = uploaderUserName;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getDisplayName() {
		return this.displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	@Override
	public String toString() {
		return "Document Uploaded: [File Name: " + this.getFileName() + ", Display Name: " + this.getDisplayName() + ", Document Type: " + this.getDocumentType() + ", Content Type: " + this.getContentType()  + ", uploadedBy: "+this.getUploaderUserName() ; 
	}
	
}
