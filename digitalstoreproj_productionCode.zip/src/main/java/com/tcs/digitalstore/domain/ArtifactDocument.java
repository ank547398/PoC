package com.tcs.digitalstore.domain;

/**
 * Holds the details of the document attached with the artifact. 
 * @author 1253182
 *
 */
public class ArtifactDocument {
	private String fileId;
	
	private String fileName;
	
	private String displayName;
	
	private String documentType;
	
	private String uploaderUserName;
	
	private String contentType;
	
	private boolean isPdf;
	
	private String pdfFileId;

	public ArtifactDocument() {
		
	}
		
	public ArtifactDocument(String fileId,String fileName, String displayName,
			String documentType, String uploaderUserName, String contentType,
			boolean isPdf,String pdfFileId) {
		super();
		this.fileName = fileName;
		this.displayName = displayName;
		this.documentType = documentType;
		this.uploaderUserName = uploaderUserName;
		this.fileId = fileId;
		this.contentType = contentType;
		this.isPdf = isPdf;
		this.pdfFileId = pdfFileId;
	}


	public boolean isPdf() {
		return isPdf;
	}

	public void setPdf(boolean isPdf) {
		this.isPdf = isPdf;
	}

	public String getPdfFileId() {
		return pdfFileId;
	}

	public void setPdfFileId(String pdfFileId) {
		this.pdfFileId = pdfFileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getUploaderUserName() {
		return uploaderUserName;
	}

	public void setUploaderUserName(String uploaderUserName) {
		this.uploaderUserName = uploaderUserName;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
}
