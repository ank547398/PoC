package com.tcs.digitalstore.domain;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="artifactsforpdfconversion")
public class ArtifactForPdfConversion {
	private String artifactId;
	private String failedIds;
	private String status;
	
	public String getFailedIds() {
		return failedIds;
	}

	public void setFailedIds(String failedIds) {
		this.failedIds = failedIds;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
}
