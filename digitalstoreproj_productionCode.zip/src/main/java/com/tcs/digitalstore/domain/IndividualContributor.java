package com.tcs.digitalstore.domain;

public class IndividualContributor {
	private String contributorEmployeeId;
	private String contributorName;
	private int count;
	private int views;
	private int downloads;
	private int likes;
	private float rating;
	private String profilePicFileId;

	public String getProfilePicFileId() {
		return profilePicFileId;
	}
	public void setProfilePicFileId(String profilePicFileId) {
		this.profilePicFileId = profilePicFileId;
	}
	
	public String getContributorName() {
		return contributorName;
	}
	public void setContributorName(String contributorName) {
		this.contributorName = contributorName;
	}
	
	public String getContributorEmployeeId() {
		return contributorEmployeeId;
	}
	
	public void setContributorEmployeeId(String contributorEmployeeId) {
		this.contributorEmployeeId = contributorEmployeeId;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	public int getDownloads() {
		return downloads;
	}
	public void setDownloads(int downloads) {
		this.downloads = downloads;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
}
