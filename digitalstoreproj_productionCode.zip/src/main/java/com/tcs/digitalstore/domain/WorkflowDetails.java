package com.tcs.digitalstore.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

public class WorkflowDetails {
	
	@Pattern(regexp="[0-9A-Za-z]{1,24}",message="Invalid artifact id.")
	@NotNull(message="Artifact id cannot be null or empty.")
	@NotEmpty(message="Artifact id cannot be null or empty.")
	private String id;
	
	@NotEmpty(message="Approver employee id cannot be empty or null.")
	@NotNull(message="Approver employee id cannot be empty or null.")
	@Pattern(regexp="\\d{3,10}",message="Only digits are allowed (minimum 3 digits and maximum 10 digits).")
	private String approverEmployeeId;
	
	@Pattern(regexp="{approved|rejected}",message="Provide valid approval status (approved or rejected).")
	private String approvalStatus;
	
	@Pattern(regexp="^[^<>'\\\"/;`%]*$",message="Characters like < > \" \\ ; % are not permissible.")
	@Length(max=256,message="Maximum 256 characters are allowed in remarks.")
	private String approvalComments;
	
	private String approverName;

	private String approvalDate;
	
	
	
	private String pendingWith;
	
	private String role;
	
	
	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	
	public String getApproverEmployeeId() {
		return this.approverEmployeeId;
	}
	
	public void setApproverEmployeeId(String approverEmployeeId) {
		this.approverEmployeeId = approverEmployeeId;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the approvalStatus
	 */
	public String getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the approvalDate
	 */
	public String getApprovalDate() {
		return approvalDate;
	}

	/**
	 * @param approvalDate the approvalDate to set
	 */
	public void setApprovalDate(String approvalDate) {
		this.approvalDate = approvalDate;
	}

	/**
	 * @return the approvalComments
	 */
	public String getApprovalComments() {
		return approvalComments;
	}

	/**
	 * @param approvalComments the approvalComments to set
	 */
	public void setApprovalComments(String approvalComments) {
		this.approvalComments = approvalComments;
	}

	/**
	 * @return the pendingWith
	 */
	public String getPendingWith() {
		return pendingWith;
	}

	/**
	 * @param pendingWith the pendingWith to set
	 */
	public void setPendingWith(String pendingWith) {
		this.pendingWith = pendingWith;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowDetails [id=" + id + ", approvalStatus=" + approvalStatus + ", approvalDate=" + approvalDate
				+ ", approvalComments=" + approvalComments + ", pendingWith=" + pendingWith + ", role=" + role + "]";
	}
	
	

	
	
}
