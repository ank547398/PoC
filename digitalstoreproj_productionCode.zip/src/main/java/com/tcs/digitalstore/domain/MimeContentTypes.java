package com.tcs.digitalstore.domain;

public enum MimeContentTypes {
	DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
	XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
	PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation"),
	DOC("application/msword"),
	
	PDF("application/pdf"),
	
	GIF("image/gif"),
	PNG("image/png"),
	TIFF("image/tiff"),
	JPEG("image/jpeg"),
	
	TEXT("text/plain");
	
	private String value;
	
	private MimeContentTypes(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public static MimeContentTypes getMimeType(String src) {
		return MimeContentTypes.valueOf(src);
	}
	
	
	
}
