package com.tcs.digitalstore.domain;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;


public class GeMatixUserDetails {
	@NotEmpty(message="Employee Id cannot be null or empty.")
	@Pattern(regexp="\\d{3,10}",message="Only digits are allowed in Employee Id {Minimum 3 digits and Maximum 10 digits}.")
	private String userId;
	
	@NotEmpty(message="Name cannot be null or empty.")
	@Pattern(regexp="^[A-Za-z]+[A-Za-z. ]*[A-Za-z ]$",message="Provide valid name.")
	@Length(min=4,max=128,message="Must begin with alphabet and may contain space and period along with alphabets (Minimum 4, maximum 128 alphabets).")
	private String userName;
	
	
	@Length(min=0,max=128,message="Maximum 128 characters are allowed for portal role.")
	private String portalRole;
	
	@NotEmpty(message="Mail id cannot be empty.")
	@Length(min=7,max=32,message="Mail id should contain atleast 7 characters and maximum 32 characters.")
	@Email(message="Please provide valid mail id.")
	private String userEmailId;
	
	@Length(min=0,max=128,message="Maximum 256 characters are allowed for user business.")
	private String userBusiness;
	
	private String digest;
	
	
	public String getDigest() {
		return digest;
	}
	
	public void setDigest(String digest) {
		this.digest = digest;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId.trim();
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName.trim();
	}
	public String getPortalRole() {
		return portalRole;
	}
	public void setPortalRole(String portalRole) {
		this.portalRole = portalRole.trim();
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId.trim();
	}
	public String getUserBusiness() {
		return userBusiness.trim();
	}
	public void setUserBusiness(String userBusiness) {
		this.userBusiness = userBusiness.trim();
	}
	
	public String toString() {
		return this.userId.trim() + this.userName.trim() + this.userEmailId.trim() + this.userBusiness.trim() + this.portalRole.trim();
	}
}
