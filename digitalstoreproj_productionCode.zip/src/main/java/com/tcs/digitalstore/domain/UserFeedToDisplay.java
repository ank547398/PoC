package com.tcs.digitalstore.domain;

public class UserFeedToDisplay {
	private String userId;
	private String userName;
	private String artifactId;
	private String employeeId;
	private String feedType;
	private String logoUrl;
	private String feedText1;
	private String feedText2;
	
	public String getFeedType() {
		return feedType;
	}
	
	public void setFeedType(String feedType) {
		this.feedType = feedType;
	}
	
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public String getFeedText1() {
		return feedText1;
	}
	public void setFeedText1(String feedText1) {
		this.feedText1 = feedText1;
	}
	public String getFeedText2() {
		return feedText2;
	}
	public void setFeedText2(String feedText2) {
		this.feedText2 = feedText2;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}
	
	
}
