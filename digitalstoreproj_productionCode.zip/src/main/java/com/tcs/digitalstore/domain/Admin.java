package com.tcs.digitalstore.domain;

import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.tcs.digitalstore.domain.validationchecks.AuthenticationChecks;
import com.tcs.digitalstore.domain.validationchecks.RegisterUserChecks;
import com.tcs.digitalstore.domain.validationchecks.ResetPasswordChecks;
import com.tcs.digitalstore.domain.validationchecks.UserRegistrationApprovalChecks;


public class Admin {
	
	
	@NotEmpty(message="Employee Id cannot be empty or null.",groups={RegisterUserChecks.class,UserRegistrationApprovalChecks.class,ResetPasswordChecks.class})
	@Pattern(regexp="\\d{3,10}",message="Only digits are allowed (minimum 3 digits and maximum 10 digits).",groups={RegisterUserChecks.class,UserRegistrationApprovalChecks.class,ResetPasswordChecks.class})
	@Indexed(unique = true)
	private String employeeId;
	
	@NotEmpty(message="Role cannot be empty or null.",groups={UserRegistrationApprovalChecks.class})
	@Pattern(regexp = "Admin|Manager|Guest", flags = Pattern.Flag.CASE_INSENSITIVE,message="Provide valid role {Admin/ Guest/ Manager}. ",groups={UserRegistrationApprovalChecks.class,RegisterUserChecks.class})
	private String role;
	
	@NotEmpty(message="Approval status cannot be empty.",groups={UserRegistrationApprovalChecks.class})
	@Pattern(regexp = "pending|approved|rejected", flags = Pattern.Flag.CASE_INSENSITIVE,message="Invalid approval status. Permissible approval status: {pending, approved, rejected}",groups={UserRegistrationApprovalChecks.class})
	private String approvalStatus;
	
	@NotEmpty(message="Name cannot be empty.",groups={RegisterUserChecks.class})
	@Pattern(regexp="^[A-Za-z]+[A-Za-z. ]*[A-Za-z]$",message="Provide valid name.",groups={RegisterUserChecks.class})
	@Length(min=4,max=128,message="Must begin with alphabet and may contain space and period along with alphabets (Minimum 4, maximum 128 alphabets).",groups={RegisterUserChecks.class})
	private String fullName;
	
	@NotEmpty(message="Mail id cannot be empty.",groups={RegisterUserChecks.class})
	@Length(min=7,max=32,message="Mail id should contain atleast 7 characters and maximum 32 characters.",groups={RegisterUserChecks.class})
	@Indexed(unique = true)
	@Email(message="Please provide valid mail id.")
	private String emailId;
	
	@NotEmpty(message="Business Unit cannot be empty.",groups={RegisterUserChecks.class})
	@Pattern(regexp="^[a-zA-Z]+[A-Za-z0-9 ]*$",message="Business unit must being with alphabet and only alphanumeric characters along with space are permissible.",groups={RegisterUserChecks.class})
	@Length(min=4,max=32,message="Business unit should contain minimum 4 and maximum 32 permissible characters.",groups={RegisterUserChecks.class,AuthenticationChecks.class})
	private String businessUnit;
	
	@NotEmpty(message="User name cannot be empty or null.",groups={RegisterUserChecks.class,AuthenticationChecks.class})
	@Pattern(regexp="^[A-Za-z]+[A-Za-z0-9]*$",message="Must begin with alphabet and may contain only alphanumeric characters (minimum 4 and maximum 32).",groups={RegisterUserChecks.class,AuthenticationChecks.class})
	@Length(min=4,max=32,message="Must begin with alphabet and may contain only alphanumeric characters (minimum 4 and maximum 32).",groups={RegisterUserChecks.class,AuthenticationChecks.class})
	@Indexed(unique = true)
	private String userId;
	
	@DateTimeFormat(iso=ISO.DATE_TIME)
	private Date approvalDate;
	
	@NotEmpty(message="Employee Id cannot be empty or null.",groups={RegisterUserChecks.class,UserRegistrationApprovalChecks.class,ResetPasswordChecks.class})
	@Pattern(regexp="\\d{3,10}",message="Only digits are allowed (minimum 3 digits and maximum 10 digits).",groups={RegisterUserChecks.class,UserRegistrationApprovalChecks.class,ResetPasswordChecks.class})
	@Indexed(unique = true)
	private String approverId;
	
	@NotEmpty(message="Name cannot be empty.",groups={RegisterUserChecks.class})
	@Pattern(regexp="^[A-Za-z]+[A-Za-z. ]*[A-Za-z]$",message="Provide valid name.",groups={RegisterUserChecks.class})
	@Length(min=4,max=128,message="Must begin with alphabet and may contain space and period along with alphabets (Minimum 4, maximum 128 alphabets).",groups={RegisterUserChecks.class})
	private String approverName;
	
	private String appName;
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getApproverId() {
		return approverId;
	}
	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}
	public String getApproverName() {
		return approverName;
	}
	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	
	
	public Date getApprovalDate() {
		return approvalDate;
	}
	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

}
