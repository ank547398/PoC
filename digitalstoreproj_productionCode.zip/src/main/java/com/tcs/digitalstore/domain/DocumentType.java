package com.tcs.digitalstore.domain;

public enum DocumentType {
	LOGO("Logo"),
	FLYER("Flyer"),
	PRESENTATION("Presentation");
	
	private String value;
	// private List<String> allowedExtensions;
	
	private DocumentType(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
}
