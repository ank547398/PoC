package com.tcs.digitalstore.domain;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="sessions")
public class SessionData {
	private String id;
	@Indexed(unique = true)
	private String	tokenIssued;
	private String userName;
	private long issuedDateTime;
	private long expiryDateTime;
	
	
	
	/**
	 * @param tokenIssued
	 * @param userId
	 * @param userName
	 * @param issuedDateTime
	 * @param expiryDateTime
	 */
	public SessionData(String tokenIssued, String userName,
			long issuedDateTime, long expiryDateTime) {
		super();
		this.tokenIssued = tokenIssued;
		this.userName = userName;
		this.issuedDateTime = issuedDateTime;
		this.expiryDateTime = expiryDateTime;
	}

	public SessionData(){
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getTokenIssued() {
		return tokenIssued;
	}
	public void setTokenIssued(String tokenIssued) {
		this.tokenIssued = tokenIssued;
	}
	public long getIssuedDateTime() {
		return issuedDateTime;
	}
	public void setIssuedDateTime(long issuedDateTime) {
		this.issuedDateTime = issuedDateTime;
	}
	public long getExpiryDateTime() {
		return expiryDateTime;
	}
	public void setExpiryDateTime(long expiryDateTime) {
		this.expiryDateTime = expiryDateTime;
	}
}
