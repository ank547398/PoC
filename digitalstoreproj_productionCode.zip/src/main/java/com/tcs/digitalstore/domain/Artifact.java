package com.tcs.digitalstore.domain;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

//import com.tcs.digitalstore.utility.StringPropertyEditor;

@Document(collection="artifacts")
public class Artifact {
	
	@Id private String id;
	private @TextIndexed(weight = 3) String name;
	private @TextIndexed(weight = 2) String promoText;
	private @TextIndexed(weight = 2) String solution;
	private String version;
	/**
	 * GE Business division
	 * 		1. Healthcare
	 * 		2. Capital
	 * 		3. Aviation
	 * 		4. Power and Water
	 * 		5. Transportation
	 * 		6. Oil and Gas
	 * 		7. Corporate
	 * 		8. Engineering
	 * 		9. Element
	 */
	private @TextIndexed(weight = 2) String business;
	/**
	 * Category of the artifact uploaded:
	 * 		1. Remote Services
	 * 		2. Field Services
	 * 		3. Shop Floor Services
	 * 		4. Contractual 
	 * 		5. After market services. 
	 */
	private String businessbenefit;
	/**
	 * Business benefit the artifact provided. 		
	 * 		1. Supply chain
	 * 		2. Engineering
	 * 		3. Sales
	 * 		4. Finance
	 * 		5. Human Resource 
	 * 		6. Marketing
	 * 		7. Services 
	 */
	private @TextIndexed(weight = 3) String category;
	private @TextIndexed(weight = 2) List<String> functions;
	private String appType;
	
	private @DateTimeFormat(iso = ISO.DATE_TIME) Date submissionDate;
	private String uploaderId;
	private String uploaderEmployeeId;
	private String uploaderUserName;
	
	private String approvalStatus;
	private @DateTimeFormat(iso = ISO.DATE_TIME) Date approvalDate;
	private String approverId;
	private String approverEmployeeId;
	private String approverName;
	private String approverComments;
	
	private int downloads;
	private int views;
	private int likes;
	private float rating;
	private int ratingCount;
	private int popularityPercent;
	
	private int DayDiff;
	private String logoURL;
	private String flyerId;
	
	private List<ContactPerson> contactPersons;
	private List<ArtifactDocument> artifactDocuments;
	private List<String> deletedFileId;
	
	private int modifyCount;

	public int getModifyCount() {
		return modifyCount;
	}


	public void setModifyCount(int modifyCount) {
		this.modifyCount = modifyCount;
	}
	
	public List<String> getDeletedFileId() {
		return deletedFileId;
	}


	public void setDeletedFileId(List<String> deletedFileId) {
		this.deletedFileId = deletedFileId;
	}
	
	private String oldArtifactId;

	public String getOldArtifactId() {
		return oldArtifactId;
	}


	public void setOldArtifactId(String oldArtifactId) {
		this.oldArtifactId = oldArtifactId;
	}
	public Artifact() {
	}
	
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		// this.name = name.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&").replace("&ndash;", "-").replace("&rsquo;", "'"); 
	}
	
	public String getPromoText() {
		return promoText;
	}
	public void setPromoText(String promoText) {
		this.promoText = promoText;
	}
	
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
		// this.solution = solution.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&").replace("&ndash;", "-").replace("&rsquo;", "'");
	}
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}
	
	public String getBusinessbenefit() {
		return businessbenefit;
	}
	public void setBusinessbenefit(String businessbenefit) {
		this.businessbenefit = businessbenefit;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}
	
	public int getRatingCount() {
		return ratingCount;
	}


	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}


	public int getDayDiff() {
		return DayDiff;
	}

	public String getApproverName() {
		return approverName;
	}


	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	public void setDayDiff(int dayDiff) {
		DayDiff = dayDiff;
	}
	
	public int getPopularityPercent() {
		return popularityPercent;
	}

	public void setPopularityPercent(int popularityPercent) {
		this.popularityPercent = popularityPercent;
	}

	
	public List<String> getFunctions() {
		return functions;
	}
	public void setFunctions(List<String> functions) {
		this.functions = functions;
	}
	
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}

	
	
	
	
	public String getUploaderId() {
		return uploaderId;
	}
	public void setUploaderId(String uploaderId) {
		this.uploaderId = uploaderId;
	}
	public String getUploaderEmployeeId() {
		return uploaderEmployeeId;
	}
	public void setUploaderEmployeeId(String uploaderEmployeeId) {
		this.uploaderEmployeeId = uploaderEmployeeId;
	}
	
	public String getUploaderUserName() {
		return this.uploaderUserName;
	}
	public void setUploaderUserName(String uploaderUserName) {
		this.uploaderUserName = uploaderUserName;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}
	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}	
	
	public String getApproverComments() {
		return approverComments;
	}
	public void setApproverComments(String approverComments) {
		/*if(approverComments != null && approverComments != "")
			this.approverComments = approverComments.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&").replace("&ndash;", "-").replace("&rsquo;", "'");
		else*/
			this.approverComments = approverComments;
	}
	
	public String getApproverEmployeeId() {
		return this.approverEmployeeId;
	}	
	public void setApproverEmployeeId(String approverEmployeeId) {
		this.approverEmployeeId = approverEmployeeId;
	}
	
	public String getApproverId() {
		return approverId;
	}
	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}
	
	public int getDownloads() {
		return downloads;
	}
	public void setDownloads(int downloads) {
		this.downloads = downloads;
	}

	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}

	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	
	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public List<ArtifactDocument> getArtifactDocuments() {
		return artifactDocuments;
	}

	public void setArtifactDocuments(List<ArtifactDocument> artifactDocuments) {
		this.artifactDocuments = artifactDocuments;
	}
	
	public String getFlyerId() {
		return flyerId;
	}


	public void setFlyerId(String flyerId) {
		this.flyerId = flyerId;
	}


	public String getLogoURL() {
		return logoURL;
	}

	public void setLogoURL(String logoURL) {
		this.logoURL = logoURL;
	}

	public List<ContactPerson> getContactPersons() {
		return contactPersons;
	}

	public void setContactPersons(List<ContactPerson> contactPersons) {
		this.contactPersons = contactPersons;
	}
}
