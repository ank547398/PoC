package com.tcs.digitalstore.domain;

import java.util.List;

public class ArtifactContents {
	private DocumentUploaded logo;
	private DocumentUploaded flyer;
	private List<DocumentUploaded> files;
	
	public DocumentUploaded getLogo() {
		return logo;
	}
	
	public void setLogo(DocumentUploaded logo) {
		this.logo = logo;
	}
	
	public DocumentUploaded getFlyer() {
		return flyer;
	}
	
	public void setFlyer(DocumentUploaded flyer) {
		this.flyer = flyer;
	}
	
	public List<DocumentUploaded> getFiles() {
		return files;
	}
	
	public void setFiles(List<DocumentUploaded> files) {
		this.files = files;
	}
}
