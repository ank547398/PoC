package com.tcs.digitalstore.domain;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.tcs.digitalstore.domain.validationchecks.UserFeedChecks;
import com.tcs.digitalstore.domain.validationchecks.UserFeedRatingChecks;

@Document(collection="userFeeds")
public class UserFeed {
	@Id
	private String id;
	
	@NotEmpty(message="User Id Required.",groups={UserFeedChecks.class,UserFeedRatingChecks.class})
	@Pattern(regexp="^[0-9A-Za-z]{1,32}$",message="Provide valid user id.",groups={UserFeedChecks.class,UserFeedRatingChecks.class})
	private String userId;
	
	@NotEmpty(message="Artifact Id Required.",groups={UserFeedChecks.class,UserFeedRatingChecks.class})
	@Pattern(regexp="^[0-9A-Za-z]{1,32}$",message="Provide valid artifact id.",groups={UserFeedChecks.class,UserFeedRatingChecks.class})
	private String artifactId;
	
	@Min(value=1,message="Minimum allowed rating is 1 and maximum 5.",groups={UserFeedRatingChecks.class})
	@Max(value=5,message="Minimum allowed rating is 1 and maximum 5.",groups={UserFeedRatingChecks.class})
	private float rating;
	
	private String employeeId;
	
	private String employeeName;
	
	private String artifactName;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date feedDate;
	
	private UserFeedType userFeedType;
	
	public UserFeed() {
		
	}
	

	
	
	/**
	 * @param userId
	 * @param employeeId
	 * @param artifactId
	 * @param feedDate
	 * @param userFeedType
	 * @param rating
	 */
	public UserFeed(String userId, String employeeId, String employeeName,
			String artifactId,String artifactName,Date feedDate,UserFeedType userFeedType, 
			float rating) {
		super();
		
		this.userId = userId;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		
		this.artifactId = artifactId;
		this.artifactName = artifactName;
		
		this.feedDate = feedDate;
		this.userFeedType = userFeedType;
		this.rating = rating;
	}

	

	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	public String getArtifactName() {
		return artifactName;
	}



	public void setArtifactName(String artifactName) {
		this.artifactName = artifactName;
	}



	public static UserFeed buildLiked(String userId, String employeeId, String employeeName,String artifactId,String artifactName) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.LIKED,0);
	}
	
	public static UserFeed buildViewed(String userId, String employeeId, 
				String employeeName, String artifactId,String artifactName) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.VIEWED,0);
	}
	
	public static UserFeed buildDownloaded(String userId, String employeeId,String employeeName, String artifactId,String artifactName) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.DOWNLOADED,0);
	}
	
	public static UserFeed buildRated(String userId, String employeeId, String employeeName,String artifactId,String artifactName,float rating) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.RATING,rating);
	}
	
	
	public static UserFeed buildUploaded(String userId, String employeeId, String employeeName,String artifactId,String artifactName) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.UPLOADED,0);
	}
	
	public static UserFeed buildUpdated(String userId, String employeeId, String employeeName,String artifactId,String artifactName) {
		return new UserFeed(userId,employeeId,employeeName,artifactId,artifactName,new Date(),UserFeedType.UPDATED,0);
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public Date getFeedDate() {
		return feedDate;
	}

	public void setFeedDate(Date feedDate) {
		this.feedDate = feedDate;
	}

	public UserFeedType getUserFeedType() {
		return userFeedType;
	}

	public void setUserFeedType(UserFeedType userFeedType) {
		this.userFeedType = userFeedType;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}
}
