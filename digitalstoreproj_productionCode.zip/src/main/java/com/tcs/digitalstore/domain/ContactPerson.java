package com.tcs.digitalstore.domain;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

public class ContactPerson {
	
	@Length(min=3,max=10,message="Employee Id should be minimum 3 digits and maximum 10 digits.")
	@Pattern(regexp="\\d{3,10}",message="Only digits are permissible in the employee number.")
	private String employeeId;
	
	@Length(min=4,max=128,message="Name should have minimum 4 characters and maximum 128 characters.")
	@Pattern(regexp="^[A-Za-z]+[A-Za-z. ]*[A-Za-z]$",message="Provide valid name.")
	private String employeeName;
	
	@Length(min=10,max=50,message="Mail id should contain atleast 10 characters and maximum 50 characters.")
	@Email(message="Please provide valid mail id.")
	private String mailId;
	
	@Length(min=3,max=32,message="Minimum 3, maximum 32 characters are permissible in role.")
	@Pattern(regexp="^[A-Za-z]+[A-Za-z. ]*[A-Za-z]$",message="Provide valid role.")
	private String role;

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		 this.employeeId = employeeId;
		//this.employeeId = employeeId.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&"); 
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		 this.employeeName = employeeName;
		//this.employeeName = employeeName.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&");
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		 this.mailId = mailId;
		//this.mailId = mailId.replace("\\r\\n", "\n").replace("//", "").replace("\\", "").replace("'", "").replace("&amp;", "&");
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
	public String toString() {
		return "employeeId: " + this.getEmployeeId() + ", employeeName: " + this.getEmployeeName() + ", mailId: " + this.getMailId() + ", role: "+this.getRole() ; 
	}
}
