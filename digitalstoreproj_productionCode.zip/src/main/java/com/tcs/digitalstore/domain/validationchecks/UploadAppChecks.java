package com.tcs.digitalstore.domain.validationchecks;

public class UploadAppChecks {

}
